export type GradeLevel = '고1 공통' | '고2 일반선택' | '고3 진로·융합선택';

export type AssessmentType =
  | '탐구 보고서'
  | '발표·PPT'
  | '실험·실습'
  | '코딩·데이터 분석'
  | '토론·논술'
  | '프로젝트·제작';

export interface InquiryRequest {
  topic: string;
  subject: string;
  gradeLevel: GradeLevel;
  assessmentType: AssessmentType;
  conditions: string;
  targetMajor: string;
  competencies: string[];
  additionalFocus: string;
}

export interface FollowUpInquiry {
  title: string;
  linkedSubject: string;
  direction: string;
  storylineNote: string;
}

export interface RecommendedTopic {
  id: string;
  approachType: string;
  title: string;
  researchQuestion: string;
  curriculumConnection: string;
  methodology: string[];
  deliverableFormat: string;
  pros: string[];
  cons: string[];
  competencyAlignment: string;
  difficulty: '기초·안정' | '심화·도전' | '융합·확장';
  estimatedHours: string;
  followUps: FollowUpInquiry[];
}

export interface RecommendationResponse {
  advisorSummary: string;
  topics: RecommendedTopic[];
}

export interface OutlineSection {
  section: string;
  details: string;
}

export interface InquiryPlanOutline {
  hypothesis: string;
  tableOfContents: OutlineSection[];
  dataAndTools: string[];
  evaluationChecklist: string[];
  searchKeywords: string[];
}

export interface SavedTopicItem extends RecommendedTopic {
  savedAt: string;
  requestSnapshot: InquiryRequest;
  outline?: InquiryPlanOutline;
}

export interface TeamMemberPresence {
  clientId: string;
  name: string;
  role: string;
  color: string;
  joinedAt: string;
}

export type TaskStatus = 'todo' | 'in_progress' | 'done';

export interface TeamTask {
  id: string;
  title: string;
  assignee: string;
  dueLabel: string;
  status: TaskStatus;
  updatedBy: string;
  updatedAt: string;
}

export type FeedbackKind = 'feedback' | 'progress' | 'idea' | 'question';

export interface FeedbackEntry {
  id: string;
  authorName: string;
  authorRole: string;
  kind: FeedbackKind;
  content: string;
  createdAt: string;
  likes: string[];
  resolved: boolean;
}

export interface TopicDraftRevision {
  version: number;
  updatedBy: string;
  updatedAt: string;
  note: string;
  title: string;
  researchQuestion: string;
  hypothesis: string;
  deliverableFormat: string;
  methodology: string[];
}

export interface SharedInquiryRoom {
  roomId: string;
  createdAt: string;
  createdBy: string;
  subject: string;
  gradeLevel: GradeLevel;
  assessmentType: AssessmentType;
  targetMajor: string;
  competencies: string[];
  currentTopic: RecommendedTopic;
  hypothesis: string;
  revisions: TopicDraftRevision[];
  tasks: TeamTask[];
  feedbacks: FeedbackEntry[];
}
