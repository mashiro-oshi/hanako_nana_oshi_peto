const RAW_BACKEND_URL = (import.meta.env.VITE_BACKEND_URL || '').trim().replace(/\/+$/, '');

export function collabApiUrl(path: string): string {
  return RAW_BACKEND_URL ? `${RAW_BACKEND_URL}${path}` : path;
}

export function collabWsUrl(path: string): string {
  if (RAW_BACKEND_URL) {
    const wsBase = RAW_BACKEND_URL.replace(/^https:\/\//i, 'wss://').replace(/^http:\/\//i, 'ws://');
    return `${wsBase}${path}`;
  }
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${protocol}//${window.location.host}${path}`;
}

export async function parseJsonSafe<T>(res: Response, fallbackMsg: string): Promise<T> {
  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    throw new Error(fallbackMsg);
  }
  const data = (await res.json()) as T & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || fallbackMsg);
  }
  return data;
}
