import React, { useEffect, useRef, useState } from 'react';
import { ArrowRight, BookOpenCheck, Users } from 'lucide-react';
import { CollaborativeWorkspace } from './components/CollaborativeWorkspace';
import { ComparisonTable } from './components/ComparisonTable';
import { InquiryForm } from './components/InquiryForm';
import { SavedTopicsView } from './components/SavedTopicsView';
import { TopicCard } from './components/TopicCard';
import { QUICK_SCENARIOS } from './data/presets';
import type {
  FollowUpInquiry,
  InquiryPlanOutline,
  InquiryRequest,
  RecommendationResponse,
  RecommendedTopic,
  SavedTopicItem,
} from './types/inquiry';

type AppView = 'design' | 'compare' | 'collab' | 'saved';

const STORAGE_KEY = 'inquiry-atelier-saved-topics-v1';

const DEFAULT_REQUEST: InquiryRequest = {
  topic: '',
  subject: '',
  gradeLevel: '고2 일반선택',
  assessmentType: '탐구 보고서',
  conditions: '',
  targetMajor: '',
  competencies: ['수리·논리적 모델링', '학제간 융합 사고'],
  additionalFocus: '',
};

function getInitialRoomFromUrl(): string | null {
  try {
    const params = new URLSearchParams(window.location.search);
    const roomParam = params.get('room');
    return roomParam ? roomParam.toUpperCase().trim() : null;
  } catch {
    return null;
  }
}

export default function App() {
  const initialUrlRoom = getInitialRoomFromUrl();

  const [activeView, setActiveView] = useState<AppView>(initialUrlRoom ? 'collab' : 'design');
  const [activeRoomId, setActiveRoomId] = useState<string | null>(initialUrlRoom);

  const [request, setRequest] = useState<InquiryRequest>(DEFAULT_REQUEST);
  const [result, setResult] = useState<RecommendationResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [outlines, setOutlines] = useState<Record<string, InquiryPlanOutline>>({});
  const [outlineLoadingId, setOutlineLoadingId] = useState<string | null>(null);
  const [creatingRoomTopicId, setCreatingRoomTopicId] = useState<string | null>(null);

  const [savedTopics, setSavedTopics] = useState<SavedTopicItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as SavedTopicItem[]) : [];
    } catch {
      return [];
    }
  });

  const topicCardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(savedTopics));
    } catch {
      // Ignore storage quota issues
    }
  }, [savedTopics]);

  const syncRoomUrl = (roomId: string | null) => {
    setActiveRoomId(roomId);
    try {
      const url = new URL(window.location.href);
      if (roomId) {
        url.searchParams.set('room', roomId);
      } else {
        url.searchParams.delete('room');
      }
      window.history.replaceState({}, '', url.toString());
    } catch {
      // Ignore history API restrictions
    }
  };

  async function readJsonSafely<T>(res: Response): Promise<T & { error?: string }> {
    const text = await res.text();
    try {
      return JSON.parse(text) as T & { error?: string };
    } catch {
      throw new Error(
        res.ok
          ? '서버 응답을 해석하지 못했습니다. 잠시 후 다시 시도해 주세요.'
          : `서버 오류가 발생했습니다 (HTTP ${res.status}). 잠시 후 다시 시도해 주세요.`
      );
    }
  }

  const runRecommend = async (payload: InquiryRequest) => {
    if (!payload.topic.trim()) {
      setErrorMessage('탐구 주제 또는 관심 키워드를 입력해 주세요.');
      return;
    }
    if (!payload.targetMajor.trim()) {
      setErrorMessage('지망학과 또는 희망 진로 계열을 입력해 주세요.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await readJsonSafely<RecommendationResponse>(res);
      if (!res.ok) {
        throw new Error(data.error || '탐구 주제를 생성하지 못했습니다.');
      }
      setResult(data as RecommendationResponse);
      setActiveView('design');
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : '요청 중 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoadSample = () => {
    const sample = QUICK_SCENARIOS[0].request;
    setRequest(sample);
    setErrorMessage(null);
    setActiveView('design');
  };

  const handleRunQuickScenario = (scenarioRequest: InquiryRequest) => {
    setRequest(scenarioRequest);
    setErrorMessage(null);
    runRecommend(scenarioRequest);
  };

  const handleRequestOutline = async (topic: RecommendedTopic) => {
    setOutlineLoadingId(topic.id);
    setErrorMessage(null);
    try {
      const res = await fetch('/api/outline', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topicData: topic,
          requestContext: request,
        }),
      });
      const data = await readJsonSafely<InquiryPlanOutline>(res);
      if (!res.ok) {
        throw new Error(data.error || '상세 계획서를 생성하지 못했습니다.');
      }
      setOutlines((prev) => ({
        ...prev,
        [topic.id]: data as InquiryPlanOutline,
      }));
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : '계획서 생성 중 오류가 발생했습니다.');
    } finally {
      setOutlineLoadingId(null);
    }
  };

  const handleToggleSave = (topic: RecommendedTopic) => {
    setSavedTopics((prev) => {
      const exists = prev.some((item) => item.id === topic.id && item.title === topic.title);
      if (exists) {
        return prev.filter((item) => !(item.id === topic.id && item.title === topic.title));
      }
      const nextItem: SavedTopicItem = {
        ...topic,
        savedAt: new Date().toISOString(),
        requestSnapshot: { ...request },
        outline: outlines[topic.id],
      };
      return [nextItem, ...prev];
    });
  };

  const handleRemoveSaved = (topicId: string) => {
    setSavedTopics((prev) => prev.filter((item) => item.id !== topicId));
  };

  const handleExploreFollowUp = (followUp: FollowUpInquiry) => {
    const nextRequest: InquiryRequest = {
      ...request,
      topic: followUp.title,
      subject: followUp.linkedSubject.split('/')[0].trim(),
      additionalFocus: `${followUp.direction} (${followUp.storylineNote})`,
    };
    setRequest(nextRequest);
    setActiveView('design');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCreateCollabRoom = async (topic: RecommendedTopic | SavedTopicItem) => {
    setCreatingRoomTopicId(topic.id);
    setErrorMessage(null);
    try {
      let creatorName = '김민준';
      try {
        creatorName = localStorage.getItem('inquiry-atelier-member-name') || '김민준';
      } catch {
        // Ignore storage error
      }
      const contextToUse = 'requestSnapshot' in topic ? topic.requestSnapshot : request;
      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          requestContext: contextToUse,
          creatorName,
        }),
      });
      const data = await readJsonSafely<{ room: { roomId: string } }>(res);
      if (!res.ok) {
        throw new Error(data.error || '협업방을 생성하지 못했습니다.');
      }
      syncRoomUrl(data.room.roomId);
      setActiveView('collab');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : '협업방 생성 중 오류가 발생했습니다.');
    } finally {
      setCreatingRoomTopicId(null);
    }
  };

  const handleSelectComparisonTopic = (topicId: string) => {
    setActiveView('design');
    setTimeout(() => {
      topicCardRefs.current[topicId]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  };

  const navItems: { key: AppView; label: string }[] = [
    { key: 'design', label: '주제 설계' },
    { key: 'compare', label: '장단점 비교' },
    { key: 'collab', label: '팀 협업방' },
    { key: 'saved', label: `내 보관함 (${savedTopics.length})` },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-900">
      {/* Top Bar Contract: 3 exact zones separated by gap-8 */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-slate-200">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-8">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              setActiveView('design');
            }}
            className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            탐구아틀리에
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
            {navItems.map((item) => {
              const isActive = activeView === item.key;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => setActiveView(item.key)}
                  className={`py-5 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'border-blue-800 text-slate-950 font-semibold'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handleLoadSample}
              className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              예시 불러오기
            </button>
          </div>
        </div>

        {/* Mobile navigation strip */}
        <div className="md:hidden border-t border-slate-200 px-4 py-2 flex items-center gap-2 overflow-x-auto">
          {navItems.map((item) => {
            const isActive = activeView === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => setActiveView(item.key)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-[1360px] w-full mx-auto px-4 sm:px-8 py-8 space-y-8">
        {/* Intro Editorial Header */}
        <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-6 border-b border-slate-200">
          <div className="space-y-2 max-w-3xl">
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              2022 개정 교육과정 수행평가 · 세특 탐구 주제 설계
            </h1>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              관심 주제와 수행평가 조건, 지망학과, 보여주고 싶은 역량을 입력하면 주제별 장단점과 후속 탐구까지 한 번에 설계하고 친구와 실시간 협업방에서 발전시킬 수 있습니다.
            </p>
          </div>

          {activeView !== 'collab' && (
            <button
              type="button"
              onClick={() => setActiveView('collab')}
              className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-blue-800 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-4 py-2.5 rounded-lg transition-colors whitespace-nowrap self-start lg:self-end shrink-0 cursor-pointer"
            >
              <Users className="w-4 h-4" />
              <span>{activeRoomId ? `진행 중인 팀방 (${activeRoomId}) 열기` : '초대 코드로 팀 협업방 입장'}</span>
            </button>
          )}
        </section>

        {errorMessage && activeView !== 'design' && (
          <div
            role="alert"
            className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 flex items-center justify-between gap-4"
          >
            <span>{errorMessage}</span>
            <button
              type="button"
              onClick={() => setErrorMessage(null)}
              className="text-xs font-semibold text-red-700 hover:text-red-900 whitespace-nowrap cursor-pointer"
            >
              닫기
            </button>
          </div>
        )}

        {/* View 1: Inquiry Design & Recommendations */}
        {activeView === 'design' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-5 lg:sticky lg:top-24">
              <InquiryForm
                value={request}
                onChange={setRequest}
                onSubmit={() => runRecommend(request)}
                onReset={() => {
                  setRequest(DEFAULT_REQUEST);
                  setErrorMessage(null);
                }}
                isLoading={isLoading}
                errorMessage={errorMessage}
              />
            </div>

            <div className="lg:col-span-7 space-y-6">
              {isLoading ? (
                <div className="space-y-6">
                  {[1, 2, 3].map((n) => (
                    <div
                      key={n}
                      className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-4 animate-pulse"
                    >
                      <div className="h-3 bg-slate-200 rounded w-1/3" />
                      <div className="h-6 bg-slate-200 rounded w-4/5" />
                      <div className="h-4 bg-slate-100 rounded w-full" />
                      <div className="pt-4 border-t border-slate-100 grid grid-cols-2 gap-4">
                        <div className="h-20 bg-slate-100 rounded" />
                        <div className="h-20 bg-slate-100 rounded" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : result ? (
                <div className="space-y-6">
                  {/* Advisor Summary */}
                  <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <h2 className="text-sm font-semibold text-blue-800">
                        맞춤 탐구 전략 총평 · 추천 주제 {result.topics.length}건
                      </h2>
                      <p className="text-sm text-slate-700 leading-relaxed">{result.advisorSummary}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveView('compare')}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 self-start sm:self-center cursor-pointer"
                    >
                      <span>장단점 표로 비교</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Topic Cards */}
                  {result.topics.map((topic, idx) => (
                    <div
                      key={topic.id}
                      ref={(el) => {
                        topicCardRefs.current[topic.id] = el;
                      }}
                    >
                      <TopicCard
                        index={idx}
                        topic={topic}
                        requestContext={request}
                        isSaved={savedTopics.some(
                          (item) => item.id === topic.id && item.title === topic.title
                        )}
                        outline={outlines[topic.id]}
                        isGeneratingOutline={outlineLoadingId === topic.id}
                        isCreatingRoom={creatingRoomTopicId === topic.id}
                        onToggleSave={handleToggleSave}
                        onRequestOutline={handleRequestOutline}
                        onExploreFollowUp={handleExploreFollowUp}
                        onCreateCollabRoom={handleCreateCollabRoom}
                      />
                    </div>
                  ))}
                </div>
              ) : (
                /* Empty State with Quick-Start Scenarios */
                <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
                  <div className="space-y-2">
                    <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-800">
                      <BookOpenCheck className="w-4 h-4" />
                      <span>추천 결과 구성 안내</span>
                    </div>
                    <h2 className="text-xl font-bold text-slate-900">
                      단순 키워드가 아닌, 실행 가능한 탐구 포트폴리오를 설계합니다
                    </h2>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      좌측에서 주제와 수행평가 조건, 지망학과, 보여주고 싶은 역량을 입력하면 서로 다른 관점의 3가지 탐구 주제와 함께 다음 학기 과목으로 이어지는 후속 탐구까지 제안합니다.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 pt-5 border-t border-slate-200">
                    <div className="space-y-1">
                      <div className="text-xs font-mono-tabular font-semibold text-blue-800">01. 조건 맞춤 절차</div>
                      <p className="text-sm font-semibold text-slate-900">평가 유형별 실행 단계</p>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        보고서, 실험, 코딩·데이터 분석 등 수행평가 형식과 분량 조건에 맞춘 단계별 가이드를 제공합니다.
                      </p>
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs font-mono-tabular font-semibold text-blue-800">02. 현실적 장단점</div>
                      <p className="text-sm font-semibold text-slate-900">강점과 리스크 보완책</p>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        전공 적합성 강점뿐 아니라 실제 수행 시 부딪히는 난관과 현실적 보완 전략을 함께 짚어줍니다.
                      </p>
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs font-mono-tabular font-semibold text-blue-800">03. 후속 탐구 &amp; 협업</div>
                      <p className="text-sm font-semibold text-slate-900">교과 연계 및 팀 프로젝트</p>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        다음 학년 선택 과목으로 이어지는 후속 탐구를 확인하고, 친구와 실시간 협업방을 열 수 있습니다.
                      </p>
                    </div>
                  </div>

                  <div className="pt-5 border-t border-slate-200 space-y-3">
                    <h3 className="text-sm font-semibold text-slate-900">
                      클릭 한 번으로 바로 추천받아 보기 (빠른 시작 시나리오)
                    </h3>
                    <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg">
                      {QUICK_SCENARIOS.map((scenario) => (
                        <div
                          key={scenario.label}
                          className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 transition-colors"
                        >
                          <div className="space-y-0.5">
                            <p className="text-sm font-semibold text-slate-900">{scenario.label}</p>
                            <p className="text-xs text-slate-600">{scenario.subtitle}</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRunQuickScenario(scenario.request)}
                            className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-800 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 self-start sm:self-center cursor-pointer"
                          >
                            <span>이 조건으로 추천받기</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* View 2: Comparison Matrix */}
        {activeView === 'compare' && (
          <ComparisonTable
            topics={result?.topics || []}
            onSelectDetail={handleSelectComparisonTopic}
            onCreateCollabRoom={handleCreateCollabRoom}
          />
        )}

        {/* View 3: Real-time Collaborative Workspace */}
        {activeView === 'collab' && (
          <CollaborativeWorkspace
            initialRoomId={activeRoomId}
            onRoomChange={syncRoomUrl}
            onGoRecommend={() => setActiveView('design')}
          />
        )}

        {/* View 4: Saved Topics */}
        {activeView === 'saved' && (
          <SavedTopicsView
            savedTopics={savedTopics}
            onRemoveSaved={handleRemoveSaved}
            onExploreFollowUp={handleExploreFollowUp}
            onCreateCollabRoom={handleCreateCollabRoom}
            onGoDesign={() => setActiveView('design')}
          />
        )}
      </main>

      <footer className="border-t border-slate-200 bg-white mt-12">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-8 py-5 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <span>탐구아틀리에 · 2022 개정 교육과정 고교 탐구 설계 및 팀 협업 워크스페이스</span>
          <span>교과 세특·수행평가 탐구 기획 지원</span>
        </div>
      </footer>
    </div>
  );
}
