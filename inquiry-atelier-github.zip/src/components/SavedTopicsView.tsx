import React, { useState } from 'react';
import { ArrowUpRight, Check, Copy, Trash2, Users } from 'lucide-react';
import type { FollowUpInquiry, SavedTopicItem } from '../types/inquiry';

interface SavedTopicsViewProps {
  savedTopics: SavedTopicItem[];
  onRemoveSaved: (topicId: string) => void;
  onExploreFollowUp: (followUp: FollowUpInquiry) => void;
  onCreateCollabRoom: (topic: SavedTopicItem) => void;
  onGoDesign: () => void;
}

export const SavedTopicsView: React.FC<SavedTopicsViewProps> = ({
  savedTopics,
  onRemoveSaved,
  onExploreFollowUp,
  onCreateCollabRoom,
  onGoDesign,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = async (item: SavedTopicItem) => {
    const text = [
      `# ${item.title}`,
      `- 교과/수준: ${item.requestSnapshot.gradeLevel} · ${item.requestSnapshot.subject || '미지정'} · ${item.requestSnapshot.assessmentType}`,
      `- 지망학과: ${item.requestSnapshot.targetMajor}`,
      `- 핵심 질문: ${item.researchQuestion}`,
      `- 장점: ${item.pros.join(' / ')}`,
      `- 유의점: ${item.cons.join(' / ')}`,
      `- 후속 탐구: ${item.followUps.map((f) => `[${f.linkedSubject}] ${f.title}`).join(' / ')}`,
    ].join('\n');

    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(item.id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      // Ignore clipboard failures
    }
  };

  if (savedTopics.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-4">
        <div className="space-y-1.5">
          <h3 className="text-base font-semibold text-slate-900">보관함에 저장된 탐구 주제가 없습니다</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            추천받은 주제 카드에서 &ldquo;보관함에 저장&rdquo;을 누르면 학기별 탐구 포트폴리오를 모아두고 친구와 팀 협업방으로 바로 전환할 수 있습니다.
          </p>
        </div>
        <button
          type="button"
          onClick={onGoDesign}
          className="inline-flex items-center justify-center rounded-lg bg-blue-800 hover:bg-blue-900 text-white text-sm font-semibold px-4 py-2.5 transition-colors whitespace-nowrap cursor-pointer"
        >
          주제 추천받으러 가기
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            내 탐구 보관함 <span className="font-mono-tabular text-blue-800">({savedTopics.length})</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            저장한 탐구 주제를 복사해 수행평가 계획서에 활용하거나, 친구를 초대해 팀 프로젝트로 발전시켜 보세요.
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {savedTopics.map((item, idx) => (
          <article key={item.id} className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <span className="font-mono-tabular font-semibold text-blue-800">
                    {String(idx + 1).padStart(2, '0')}.
                  </span>
                  <span>{item.requestSnapshot.gradeLevel}</span>
                  <span aria-hidden="true">·</span>
                  <span>{item.requestSnapshot.subject || item.approachType}</span>
                  <span aria-hidden="true">·</span>
                  <span>{item.requestSnapshot.targetMajor}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-tabular">
                    {new Date(item.savedAt).toLocaleDateString('ko-KR')}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-900">{item.title}</h3>
                <p className="text-sm text-slate-700">{item.researchQuestion}</p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handleCopy(item)}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  {copiedId === item.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-700" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedId === item.id ? '복사됨' : '복사'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => onCreateCollabRoom(item)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-800 hover:bg-blue-900 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>팀 협업방 열기</span>
                </button>
                <button
                  type="button"
                  onClick={() => onRemoveSaved(item.id)}
                  aria-label="보관함에서 삭제"
                  className="p-1.5 text-slate-400 hover:text-red-700 rounded-lg hover:bg-red-50 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-700 leading-relaxed">
              <div>
                <span className="font-semibold text-emerald-800">+ 장점: </span>
                <span>{item.pros.join(' / ')}</span>
              </div>
              <div>
                <span className="font-semibold text-amber-800">! 유의점: </span>
                <span>{item.cons.join(' / ')}</span>
              </div>
            </div>

            {item.followUps.length > 0 && (
              <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs text-slate-600">
                  <span className="font-semibold text-slate-800">추천 후속 탐구: </span>
                  <span>
                    [{item.followUps[0].linkedSubject}] {item.followUps[0].title}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => onExploreFollowUp(item.followUps[0])}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-blue-800 hover:text-blue-900 whitespace-nowrap cursor-pointer"
                >
                  <span>후속 주제로 새 설계</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </article>
        ))}
      </div>
    </div>
  );
};
