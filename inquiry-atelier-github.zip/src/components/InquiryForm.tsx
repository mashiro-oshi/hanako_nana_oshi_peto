import React from 'react';
import { ArrowRight, Loader2, RotateCcw } from 'lucide-react';
import {
  ASSESSMENT_TYPES,
  COMPETENCY_OPTIONS,
  GRADE_LEVELS,
  MAJOR_PRESETS,
  SUBJECT_PRESETS,
} from '../data/presets';
import type { InquiryRequest } from '../types/inquiry';

interface InquiryFormProps {
  value: InquiryRequest;
  onChange: (next: InquiryRequest) => void;
  onSubmit: () => void;
  onReset: () => void;
  isLoading: boolean;
  errorMessage: string | null;
}

export const InquiryForm: React.FC<InquiryFormProps> = ({
  value,
  onChange,
  onSubmit,
  onReset,
  isLoading,
  errorMessage,
}) => {
  const subjectsForGrade = SUBJECT_PRESETS[value.gradeLevel] || [];

  const toggleCompetency = (item: string) => {
    const exists = value.competencies.includes(item);
    const next = exists
      ? value.competencies.filter((c) => c !== item)
      : [...value.competencies, item];
    onChange({ ...value, competencies: next });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <form
      onSubmit={handleFormSubmit}
      className="bg-white border border-slate-200 rounded-xl p-6 space-y-6"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">탐구 조건 설계</h2>
          <p className="text-sm text-slate-500 mt-1">
            2022 개정 교과와 수행평가 조건을 입력하면 맞춤형 탐구 3안을 도출합니다.
          </p>
        </div>
        <button
          type="button"
          onClick={onReset}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-slate-900 py-1.5 px-2.5 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          title="입력 초기화"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>초기화</span>
        </button>
      </div>

      {/* Section 1: Topic & Curriculum */}
      <div className="pt-5 border-t border-slate-200 space-y-4">
        <div>
          <label htmlFor="inquiry-topic" className="block text-sm font-semibold text-slate-800 mb-1.5">
            01. 관심 주제 또는 단원 키워드 <span className="text-blue-700">*</span>
          </label>
          <textarea
            id="inquiry-topic"
            rows={2}
            value={value.topic}
            onChange={(e) => onChange({ ...value, topic: e.target.value })}
            placeholder="예: 인공지능 알고리즘의 편향성, 미세플라스틱의 생분해 효율, 베이즈 정리와 의료 오진율"
            className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700 transition-colors"
          />
        </div>

        <div>
          <span className="block text-xs font-medium text-slate-600 mb-2">
            2022 개정 교육과정 수준
          </span>
          <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-lg">
            {GRADE_LEVELS.map((grade) => {
              const active = value.gradeLevel === grade;
              return (
                <button
                  key={grade}
                  type="button"
                  onClick={() => onChange({ ...value, gradeLevel: grade })}
                  className={`py-2 px-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap truncate cursor-pointer ${
                    active
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {grade}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label htmlFor="inquiry-subject" className="block text-xs font-medium text-slate-600 mb-1.5">
            관련 교과목 (선택 또는 직접 입력)
          </label>
          <input
            id="inquiry-subject"
            type="text"
            value={value.subject}
            onChange={(e) => onChange({ ...value, subject: e.target.value })}
            placeholder="예: 통합과학, 확률과 통계, 사회문제 탐구"
            className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700 transition-colors"
          />
          <div className="flex flex-wrap gap-1.5 mt-2">
            {subjectsForGrade.map((subj) => {
              const selected = value.subject === subj;
              return (
                <button
                  key={subj}
                  type="button"
                  onClick={() => onChange({ ...value, subject: selected ? '' : subj })}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md border transition-colors whitespace-nowrap cursor-pointer ${
                    selected
                      ? 'bg-blue-700 text-white border-blue-700'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  {subj}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Section 2: Performance Assessment Conditions */}
      <div className="pt-5 border-t border-slate-200 space-y-4">
        <div>
          <span className="block text-sm font-semibold text-slate-800 mb-2">
            02. 수행평가 유형 및 세부 조건
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
            {ASSESSMENT_TYPES.map((type) => {
              const active = value.assessmentType === type;
              return (
                <button
                  key={type}
                  type="button"
                  onClick={() => onChange({ ...value, assessmentType: type })}
                  className={`py-2 px-2.5 text-xs font-medium rounded-lg border text-center transition-colors whitespace-nowrap truncate cursor-pointer ${
                    active
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {type}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label htmlFor="inquiry-conditions" className="block text-xs font-medium text-slate-600 mb-1.5">
            세부 조건·제약사항 (분량, 모둠 인원, 기간, 기구 제한 등)
          </label>
          <textarea
            id="inquiry-conditions"
            rows={2}
            value={value.conditions}
            onChange={(e) => onChange({ ...value, conditions: e.target.value })}
            placeholder="예: A4 3장 이내 개인 보고서, 교내 과학실 기구만 사용 가능, 5분 구술 발표 포함"
            className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700 transition-colors"
          />
        </div>
      </div>

      {/* Section 3: Target Major */}
      <div className="pt-5 border-t border-slate-200 space-y-2.5">
        <label htmlFor="inquiry-major" className="block text-sm font-semibold text-slate-800">
          03. 지망학과 또는 희망 진로 계열 <span className="text-blue-700">*</span>
        </label>
        <input
          id="inquiry-major"
          type="text"
          value={value.targetMajor}
          onChange={(e) => onChange({ ...value, targetMajor: e.target.value })}
          placeholder="예: 컴퓨터공학과, 의예과, 경영학과, 환경공학"
          className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700 transition-colors"
        />
        <div className="flex flex-wrap gap-1.5">
          {MAJOR_PRESETS.map((major) => {
            const selected = value.targetMajor === major;
            return (
              <button
                key={major}
                type="button"
                onClick={() => onChange({ ...value, targetMajor: selected ? '' : major })}
                className={`px-2.5 py-1 text-xs font-medium rounded-md border transition-colors whitespace-nowrap cursor-pointer ${
                  selected
                    ? 'bg-blue-700 text-white border-blue-700'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-100'
                }`}
              >
                {major}
              </button>
            );
          })}
        </div>
      </div>

      {/* Section 4: Competencies */}
      <div className="pt-5 border-t border-slate-200 space-y-3">
        <div>
          <span className="block text-sm font-semibold text-slate-800">
            04. 학생부·수행평가에서 보여주고 싶은 역량
          </span>
          <p className="text-xs text-slate-500 mt-0.5">복수 선택이 가능합니다.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
          {COMPETENCY_OPTIONS.map((comp) => {
            const active = value.competencies.includes(comp);
            return (
              <button
                key={comp}
                type="button"
                onClick={() => toggleCompetency(comp)}
                className={`py-2 px-3 text-xs font-medium rounded-lg border text-left transition-colors whitespace-nowrap truncate cursor-pointer ${
                  active
                    ? 'bg-blue-50 text-blue-900 border-blue-700'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {active ? `✓ ${comp}` : comp}
              </button>
            );
          })}
        </div>

        <div>
          <label htmlFor="inquiry-focus" className="block text-xs font-medium text-slate-600 mb-1.5">
            추가로 강조하고 싶은 탐구 방향 (선택)
          </label>
          <input
            id="inquiry-focus"
            type="text"
            value={value.additionalFocus}
            onChange={(e) => onChange({ ...value, additionalFocus: e.target.value })}
            placeholder="예: 선행연구 한계를 짚고 나만의 대조군 실험을 설계하고 싶습니다."
            className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700 transition-colors"
          />
        </div>
      </div>

      {errorMessage && (
        <div
          role="alert"
          className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-800"
        >
          {errorMessage}
        </div>
      )}

      <div className="pt-2">
        <button
          type="submit"
          disabled={isLoading}
          className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-blue-800 hover:bg-blue-900 disabled:bg-slate-400 text-white font-semibold text-sm py-3 px-5 transition-colors cursor-pointer disabled:cursor-not-allowed whitespace-nowrap"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>2022 개정 교과 연계 탐구 설계 중...</span>
            </>
          ) : (
            <>
              <span>맞춤 탐구 주제 추천받기</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </form>
  );
};
