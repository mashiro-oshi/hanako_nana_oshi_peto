import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  Bookmark,
  BookmarkCheck,
  Check,
  ChevronDown,
  ChevronUp,
  Copy,
  FileText,
  Loader2,
  PlusCircle,
  Share2,
  Users,
} from 'lucide-react';
import type {
  FollowUpInquiry,
  InquiryPlanOutline,
  InquiryRequest,
  RecommendedTopic,
} from '../types/inquiry';

interface TopicCardProps {
  index: number;
  topic: RecommendedTopic;
  requestContext: InquiryRequest;
  isSaved: boolean;
  outline?: InquiryPlanOutline;
  isGeneratingOutline: boolean;
  isCreatingRoom: boolean;
  onToggleSave: (topic: RecommendedTopic) => void;
  onRequestOutline: (topic: RecommendedTopic) => void;
  onExploreFollowUp: (followUp: FollowUpInquiry) => void;
  onCreateCollabRoom: (topic: RecommendedTopic) => void;
}

export const TopicCard: React.FC<TopicCardProps> = ({
  index,
  topic,
  requestContext,
  isSaved,
  outline,
  isGeneratingOutline,
  isCreatingRoom,
  onToggleSave,
  onRequestOutline,
  onExploreFollowUp,
  onCreateCollabRoom,
}) => {
  const [outlineOpen, setOutlineOpen] = useState(Boolean(outline));
  const [copied, setCopied] = useState(false);

  const handleCopyMarkdown = async () => {
    const lines = [
      `## ${index + 1}. ${topic.title}`,
      `- 접근 유형: ${topic.approachType} | 난이도: ${topic.difficulty} | 예상 시간: ${topic.estimatedHours}`,
      `- 핵심 탐구 질문: ${topic.researchQuestion}`,
      `- 2022 개정 교과 연계: ${topic.curriculumConnection}`,
      `- 지망학과·역량 연결: ${topic.competencyAlignment}`,
      '',
      '### 탐구 진행 방법',
      ...topic.methodology.map((step, i) => `${i + 1}. ${step}`),
      '',
      `### 권장 산출물: ${topic.deliverableFormat}`,
      '',
      '### 장점',
      ...topic.pros.map((p) => `- ${p}`),
      '',
      '### 유의점 및 보완 전략',
      ...topic.cons.map((c) => `- ${c}`),
      '',
      '### 이어갈 수 있는 후속 탐구',
      ...topic.followUps.map(
        (f) => `- [${f.linkedSubject}] ${f.title} — ${f.direction} (${f.storylineNote})`
      ),
    ];

    if (outline) {
      lines.push(
        '',
        '### 상세 탐구 계획서',
        `- 가설: ${outline.hypothesis}`,
        ...outline.tableOfContents.map((s) => `  - ${s.section}: ${s.details}`)
      );
    }

    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard permission fallback ignored gracefully
    }
  };

  const handleOutlineClick = () => {
    if (outline) {
      setOutlineOpen((prev) => !prev);
    } else {
      setOutlineOpen(true);
      onRequestOutline(topic);
    }
  };

  const paddedIndex = String(index + 1).padStart(2, '0');

  return (
    <article className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
      {/* Editorial metadata line (Zero-pill discipline) */}
      <div className="space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-medium">
            <span className="font-mono-tabular text-blue-800 font-semibold">{paddedIndex}.</span>
            <span>{topic.approachType}</span>
            <span aria-hidden="true">·</span>
            <span>난이도 {topic.difficulty}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-tabular">예상 {topic.estimatedHours}</span>
            {requestContext.subject && (
              <>
                <span aria-hidden="true">·</span>
                <span>{requestContext.subject}</span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyMarkdown}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? '복사됨' : '요약 복사'}</span>
            </button>
            <button
              type="button"
              onClick={() => onToggleSave(topic)}
              className={`inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1.5 rounded-lg border transition-colors whitespace-nowrap cursor-pointer ${
                isSaved
                  ? 'bg-blue-50 text-blue-800 border-blue-200'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {isSaved ? <BookmarkCheck className="w-3.5 h-3.5" /> : <Bookmark className="w-3.5 h-3.5" />}
              <span>{isSaved ? '보관됨' : '보관함에 저장'}</span>
            </button>
          </div>
        </div>

        <h3 className="text-xl font-bold text-slate-900 leading-snug">{topic.title}</h3>
        <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
          <span className="font-semibold text-slate-900">핵심 탐구 질문: </span>
          {topic.researchQuestion}
        </p>
      </div>

      {/* Curriculum & Competency Context */}
      <div className="pt-5 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-1.5">
          <h4 className="text-xs font-semibold text-slate-500">2022 개정 교육과정 연계</h4>
          <p className="text-sm text-slate-700 leading-relaxed">{topic.curriculumConnection}</p>
        </div>
        <div className="space-y-1.5">
          <h4 className="text-xs font-semibold text-slate-500">지망학과 · 선택 역량 어필 포인트</h4>
          <p className="text-sm text-slate-700 leading-relaxed">{topic.competencyAlignment}</p>
        </div>
      </div>

      {/* Methodology & Deliverable */}
      <div className="pt-5 border-t border-slate-200 space-y-3">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h4 className="text-sm font-semibold text-slate-900">수행평가 조건 맞춤형 탐구 절차</h4>
          <span className="text-xs text-slate-500">권장 산출물: {topic.deliverableFormat}</span>
        </div>
        <ol className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {topic.methodology.map((step, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700 leading-relaxed">
              <span className="font-mono-tabular text-xs font-semibold text-blue-800 pt-0.5 shrink-0">
                0{i + 1}
              </span>
              <span>{step}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Pros vs Cons (Hairline separation, dual-coded icons + text labels, NO border-l-4 stripes) */}
      <div className="pt-5 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2.5">
          <div className="flex items-center gap-1.5 text-sm font-semibold text-emerald-800">
            <PlusCircle className="w-4 h-4 shrink-0" />
            <span>주제별 장점</span>
          </div>
          <ul className="space-y-2">
            {topic.pros.map((pro, idx) => (
              <li key={idx} className="text-sm text-slate-700 leading-relaxed flex items-start gap-2">
                <span className="font-mono-tabular text-emerald-700 font-semibold shrink-0">+</span>
                <span>{pro}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="space-y-2.5">
          <div className="flex items-center gap-1.5 text-sm font-semibold text-amber-800">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>단점 · 유의점 및 보완 전략</span>
          </div>
          <ul className="space-y-2">
            {topic.cons.map((con, idx) => (
              <li key={idx} className="text-sm text-slate-700 leading-relaxed flex items-start gap-2">
                <span className="font-mono-tabular text-amber-700 font-semibold shrink-0">!</span>
                <span>{con}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Follow-up Inquiries */}
      <div className="pt-5 border-t border-slate-200 space-y-3">
        <div>
          <h4 className="text-sm font-semibold text-slate-900">이어갈 수 있는 후속 탐구</h4>
          <p className="text-xs text-slate-500 mt-0.5">
            다음 학기·학년 선택 과목과 연결해 연속성 있는 학생부 탐구 서사를 만들 수 있습니다.
          </p>
        </div>

        <div className="divide-y divide-slate-200 border-t border-b border-slate-200">
          {topic.followUps.map((followUp, idx) => (
            <div
              key={idx}
              className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <span className="font-semibold text-blue-800">후속 {idx + 1}</span>
                  <span aria-hidden="true">·</span>
                  <span>연계 과목: {followUp.linkedSubject}</span>
                </div>
                <p className="text-sm font-semibold text-slate-900">{followUp.title}</p>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {followUp.direction} — {followUp.storylineNote}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onExploreFollowUp(followUp)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-blue-800 hover:text-blue-900 px-3 py-2 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors whitespace-nowrap shrink-0 self-start sm:self-center cursor-pointer"
              >
                <span>이 주제로 이어서 설계</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Action Footer: Outline + Collaboration Room */}
      <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={handleOutlineClick}
          disabled={isGeneratingOutline}
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-800 hover:text-slate-950 bg-slate-100 hover:bg-slate-200/80 px-4 py-2.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer disabled:opacity-60"
        >
          {isGeneratingOutline ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>상세 목차·가설 생성 중...</span>
            </>
          ) : (
            <>
              <FileText className="w-4 h-4" />
              <span>{outline ? '상세 계획서(목차·가설) 보기' : '상세 계획서(목차·가설) 생성'}</span>
              {outline && (outlineOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />)}
            </>
          )}
        </button>

        <button
          type="button"
          onClick={() => onCreateCollabRoom(topic)}
          disabled={isCreatingRoom}
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-white bg-blue-800 hover:bg-blue-900 px-4 py-2.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer disabled:opacity-60"
        >
          {isCreatingRoom ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>협업방 여는 중...</span>
            </>
          ) : (
            <>
              <Users className="w-4 h-4" />
              <span>친구와 공유 · 팀 협업방 만들기</span>
              <Share2 className="w-3.5 h-3.5" />
            </>
          )}
        </button>
      </div>

      {/* Expanded Plan Outline */}
      {outline && outlineOpen && (
        <div className="pt-6 border-t border-slate-200 space-y-5 bg-slate-50/70 -mx-6 sm:-mx-8 px-6 sm:px-8 pb-2 rounded-b-xl">
          <div className="space-y-1.5">
            <h4 className="text-sm font-semibold text-slate-900">탐구 가설 및 핵심 논지</h4>
            <p className="text-sm text-slate-700 leading-relaxed">{outline.hypothesis}</p>
          </div>

          <div className="space-y-2.5">
            <h4 className="text-sm font-semibold text-slate-900">보고서 · 발표 권장 목차</h4>
            <div className="space-y-2">
              {outline.tableOfContents.map((sec, idx) => (
                <div key={idx} className="text-sm leading-relaxed">
                  <span className="font-semibold text-slate-900">{sec.section}: </span>
                  <span className="text-slate-700">{sec.details}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 border-t border-slate-200/80">
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-slate-600">추천 자료 출처 및 분석 도구</h4>
              <ul className="space-y-1.5 text-sm text-slate-700">
                {outline.dataAndTools.map((tool, idx) => (
                  <li key={idx}>· {tool}</li>
                ))}
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-slate-600">제출 전 자기점검 체크리스트</h4>
              <ul className="space-y-1.5 text-sm text-slate-700">
                {outline.evaluationChecklist.map((chk, idx) => (
                  <li key={idx}>□ {chk}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200/80 text-xs text-slate-600">
            <span className="font-semibold text-slate-800">학술 검색 키워드 (RISS·KCI): </span>
            <span>{outline.searchKeywords.join(' · ')}</span>
          </div>
        </div>
      )}
    </article>
  );
};
