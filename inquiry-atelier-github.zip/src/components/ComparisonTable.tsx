import React, { useState } from 'react';
import { AlertTriangle, ArrowUpRight, PlusCircle, Users } from 'lucide-react';
import type { RecommendedTopic } from '../types/inquiry';

interface ComparisonTableProps {
  topics: RecommendedTopic[];
  onSelectDetail: (topicId: string) => void;
  onCreateCollabRoom: (topic: RecommendedTopic) => void;
}

type FocusMode = 'all' | 'pros_cons' | 'followup';

export const ComparisonTable: React.FC<ComparisonTableProps> = ({
  topics,
  onSelectDetail,
  onCreateCollabRoom,
}) => {
  const [focusMode, setFocusMode] = useState<FocusMode>('all');

  if (topics.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-2">
        <p className="text-sm font-semibold text-slate-800">비교할 추천 주제가 아직 없습니다.</p>
        <p className="text-sm text-slate-500">
          주제 설계 탭에서 탐구 조건을 입력해 주제를 추천받으면 장단점과 후속 확장성을 나란히 비교할 수 있습니다.
        </p>
      </div>
    );
  }

  const showCoreRow = focusMode === 'all';
  const showProsCons = focusMode === 'all' || focusMode === 'pros_cons';
  const showFollowUp = focusMode === 'all' || focusMode === 'followup';

  return (
    <div className="space-y-4">
      {/* Header & Focus Filter */}
      <div className="bg-white border border-slate-200 rounded-xl px-6 py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">추천 주제 장단점 · 후속 확장성 비교</h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            항목별로 주제를 가로로 비교해 수행평가 일정과 내 강점에 가장 잘 맞는 탐구를 골라보세요.
          </p>
        </div>

        <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start sm:self-center shrink-0">
          <button
            type="button"
            onClick={() => setFocusMode('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              focusMode === 'all' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            전체 비교
          </button>
          <button
            type="button"
            onClick={() => setFocusMode('pros_cons')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              focusMode === 'pros_cons'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            장단점 집중 비교
          </button>
          <button
            type="button"
            onClick={() => setFocusMode('followup')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              focusMode === 'followup'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            교과·후속 탐구
          </button>
        </div>
      </div>

      {/* Desktop Transposed Comparison Matrix (Wide, airy columns, zero horizontal scroll) */}
      <div className="hidden lg:block bg-white border border-slate-200 rounded-xl overflow-hidden">
        <table className="w-full table-fixed border-collapse text-left">
          <thead>
            <tr className="border-b border-slate-200 divide-x divide-slate-200 align-top">
              <th className="w-40 p-5 bg-slate-50 text-xs font-semibold text-slate-500">비교 항목</th>
              {topics.map((topic, idx) => (
                <th key={topic.id} className="p-5 bg-white font-normal align-top">
                  <div className="space-y-2.5">
                    <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 font-medium">
                      <span className="font-mono-tabular font-semibold text-blue-800">
                        {String(idx + 1).padStart(2, '0')}안
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{topic.approachType}</span>
                    </div>
                    <div className="text-base font-bold text-slate-900 leading-snug">{topic.title}</div>
                    <div className="flex items-center gap-2 text-xs text-slate-600">
                      <span>난이도 {topic.difficulty}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-tabular">예상 {topic.estimatedHours}</span>
                    </div>
                    <div className="pt-1 flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onSelectDetail(topic.id)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 hover:text-slate-950 bg-slate-100 hover:bg-slate-200/80 px-2.5 py-1.5 rounded-md transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <span>상세 보기</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onCreateCollabRoom(topic)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-blue-800 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-2.5 py-1.5 rounded-md transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <Users className="w-3.5 h-3.5" />
                        <span>팀방 열기</span>
                      </button>
                    </div>
                  </div>
                </th>
              ))}
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-200 text-sm">
            {showCoreRow && (
              <tr className="divide-x divide-slate-200 align-top">
                <th className="p-5 bg-slate-50/80 text-xs font-semibold text-slate-700 align-top">
                  핵심 탐구 질문
                </th>
                {topics.map((topic) => (
                  <td key={topic.id} className="p-5 text-slate-800 leading-relaxed">
                    {topic.researchQuestion}
                  </td>
                ))}
              </tr>
            )}

            {showProsCons && (
              <>
                <tr className="divide-x divide-slate-200 align-top bg-emerald-50/20">
                  <th className="p-5 bg-slate-50/80 text-xs font-semibold text-emerald-800 align-top">
                    <div className="inline-flex items-center gap-1.5">
                      <PlusCircle className="w-4 h-4 shrink-0" />
                      <span>주제별 장점</span>
                    </div>
                  </th>
                  {topics.map((topic) => (
                    <td key={topic.id} className="p-5 align-top">
                      <ul className="space-y-3">
                        {topic.pros.map((pro, i) => (
                          <li key={i} className="flex items-start gap-2 text-slate-700 leading-relaxed">
                            <span className="font-mono-tabular text-emerald-700 font-bold shrink-0">+</span>
                            <span>{pro}</span>
                          </li>
                        ))}
                      </ul>
                    </td>
                  ))}
                </tr>

                <tr className="divide-x divide-slate-200 align-top bg-amber-50/20">
                  <th className="p-5 bg-slate-50/80 text-xs font-semibold text-amber-800 align-top">
                    <div className="inline-flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      <span>단점 · 유의점</span>
                    </div>
                  </th>
                  {topics.map((topic) => (
                    <td key={topic.id} className="p-5 align-top">
                      <ul className="space-y-3">
                        {topic.cons.map((con, i) => (
                          <li key={i} className="flex items-start gap-2 text-slate-700 leading-relaxed">
                            <span className="font-mono-tabular text-amber-700 font-bold shrink-0">!</span>
                            <span>{con}</span>
                          </li>
                        ))}
                      </ul>
                    </td>
                  ))}
                </tr>
              </>
            )}

            {showFollowUp && (
              <>
                <tr className="divide-x divide-slate-200 align-top">
                  <th className="p-5 bg-slate-50/80 text-xs font-semibold text-slate-700 align-top">
                    교과 연계 · 역량
                  </th>
                  {topics.map((topic) => (
                    <td key={topic.id} className="p-5 space-y-2.5 text-slate-700 leading-relaxed align-top">
                      <p className="text-xs text-slate-500 font-medium">{topic.curriculumConnection}</p>
                      <p>{topic.competencyAlignment}</p>
                    </td>
                  ))}
                </tr>

                <tr className="divide-x divide-slate-200 align-top">
                  <th className="p-5 bg-slate-50/80 text-xs font-semibold text-slate-700 align-top">
                    이어갈 후속 탐구
                  </th>
                  {topics.map((topic) => (
                    <td key={topic.id} className="p-5 align-top">
                      <ul className="space-y-3">
                        {topic.followUps.map((f, i) => (
                          <li key={i} className="space-y-0.5 leading-relaxed">
                            <div className="text-xs font-semibold text-blue-800">{f.linkedSubject}</div>
                            <div className="text-sm font-medium text-slate-900">{f.title}</div>
                            <div className="text-xs text-slate-600">{f.direction}</div>
                          </li>
                        ))}
                      </ul>
                    </td>
                  ))}
                </tr>
              </>
            )}

            {showCoreRow && (
              <tr className="divide-x divide-slate-200 align-top">
                <th className="p-5 bg-slate-50/80 text-xs font-semibold text-slate-700 align-top">
                  권장 산출물
                </th>
                {topics.map((topic) => (
                  <td key={topic.id} className="p-5 text-slate-700 leading-relaxed align-top">
                    {topic.deliverableFormat}
                  </td>
                ))}
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile / Tablet Stacked Readable Comparison */}
      <div className="lg:hidden space-y-4">
        {topics.map((topic, idx) => (
          <article key={topic.id} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-medium">
                <span className="font-mono-tabular font-semibold text-blue-800">
                  {String(idx + 1).padStart(2, '0')}안
                </span>
                <span aria-hidden="true">·</span>
                <span>{topic.approachType}</span>
                <span aria-hidden="true">·</span>
                <span>난이도 {topic.difficulty}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-tabular">{topic.estimatedHours}</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 leading-snug">{topic.title}</h3>
              {showCoreRow && <p className="text-sm text-slate-700 leading-relaxed">{topic.researchQuestion}</p>}
            </div>

            {showProsCons && (
              <div className="pt-4 border-t border-slate-200 space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800">
                    <PlusCircle className="w-4 h-4 shrink-0" />
                    <span>주제별 장점</span>
                  </div>
                  <ul className="space-y-2 text-sm text-slate-700 leading-relaxed">
                    {topic.pros.map((pro, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="font-mono-tabular text-emerald-700 font-bold shrink-0">+</span>
                        <span>{pro}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-800">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>단점 · 유의점</span>
                  </div>
                  <ul className="space-y-2 text-sm text-slate-700 leading-relaxed">
                    {topic.cons.map((con, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="font-mono-tabular text-amber-700 font-bold shrink-0">!</span>
                        <span>{con}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {showFollowUp && (
              <div className="pt-4 border-t border-slate-200 space-y-2.5">
                <div className="text-xs font-semibold text-slate-700">이어갈 후속 탐구</div>
                <ul className="space-y-2 text-sm">
                  {topic.followUps.map((f, i) => (
                    <li key={i} className="space-y-0.5">
                      <span className="text-xs font-semibold text-blue-800">{f.linkedSubject}</span>
                      <p className="text-slate-900 font-medium">{f.title}</p>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="pt-3 border-t border-slate-200 flex items-center gap-2">
              <button
                type="button"
                onClick={() => onSelectDetail(topic.id)}
                className="flex-1 py-2 px-3 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                상세 보기
              </button>
              <button
                type="button"
                onClick={() => onCreateCollabRoom(topic)}
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-blue-800 hover:bg-blue-900 rounded-lg cursor-pointer"
              >
                <Users className="w-3.5 h-3.5" />
                <span>팀방 열기</span>
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};
