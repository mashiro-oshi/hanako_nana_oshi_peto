import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  CheckCircle2,
  Circle,
  Clock,
  Copy,
  Edit3,
  History,
  Link2,
  Loader2,
  LogOut,
  MessageSquarePlus,
  Plus,
  Send,
  Sparkles,
  ThumbsUp,
  Trash2,
  Users,
} from 'lucide-react';
import type {
  FeedbackEntry,
  FeedbackKind,
  SharedInquiryRoom,
  TaskStatus,
  TeamMemberPresence,
  TeamTask,
} from '../types/inquiry';

interface CollaborativeWorkspaceProps {
  initialRoomId: string | null;
  onRoomChange: (roomId: string | null) => void;
  onGoRecommend: () => void;
}

type RoomTab = 'evolve' | 'tasks' | 'feedback';

const ROLE_OPTIONS = ['팀장 · 총괄', '자료·문헌조사', '실험·데이터 분석', '발표·보고서 편집'];

const KIND_LABELS: Record<FeedbackKind, string> = {
  progress: '진행 공유',
  feedback: '피드백',
  idea: '주제 아이디어',
  question: '질문·논의',
};

const STATUS_META: Record<TaskStatus, { label: string; colorClass: string }> = {
  todo: { label: '대기', colorClass: 'text-slate-600 bg-slate-100 border-slate-200' },
  in_progress: { label: '진행 중', colorClass: 'text-blue-800 bg-blue-50 border-blue-200' },
  done: { label: '완료', colorClass: 'text-emerald-800 bg-emerald-50 border-emerald-200' },
};

function getClientId(): string {
  const key = 'inquiry-atelier-client-id';
  try {
    const existing = sessionStorage.getItem(key);
    if (existing) return existing;
    const next = `stu-${Math.random().toString(36).slice(2, 10)}`;
    sessionStorage.setItem(key, next);
    return next;
  } catch {
    return `stu-${Math.random().toString(36).slice(2, 10)}`;
  }
}

export const CollaborativeWorkspace: React.FC<CollaborativeWorkspaceProps> = ({
  initialRoomId,
  onRoomChange,
  onGoRecommend,
}) => {
  const [clientId] = useState<string>(() => getClientId());
  const [memberName, setMemberName] = useState<string>(() => {
    try {
      return localStorage.getItem('inquiry-atelier-member-name') || '김민준';
    } catch {
      return '김민준';
    }
  });
  const [memberRole, setMemberRole] = useState<string>(() => {
    try {
      return localStorage.getItem('inquiry-atelier-member-role') || ROLE_OPTIONS[0];
    } catch {
      return ROLE_OPTIONS[0];
    }
  });

  const [joinCodeInput, setJoinCodeInput] = useState<string>(initialRoomId || '');
  const [activeRoomId, setActiveRoomId] = useState<string | null>(initialRoomId);
  const [room, setRoom] = useState<SharedInquiryRoom | null>(null);
  const [activeMembers, setActiveMembers] = useState<TeamMemberPresence[]>([]);
  const [wsStatus, setWsStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  const [roomError, setRoomError] = useState<string | null>(null);
  const [isLoadingRoom, setIsLoadingRoom] = useState<boolean>(false);

  const [subTab, setSubTab] = useState<RoomTab>('evolve');
  const [copiedType, setCopiedType] = useState<'link' | 'code' | null>(null);

  // Editing topic state
  const [isEditingTopic, setIsEditingTopic] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editQuestion, setEditQuestion] = useState('');
  const [editHypothesis, setEditHypothesis] = useState('');
  const [editDeliverable, setEditDeliverable] = useState('');
  const [editMethodologyText, setEditMethodologyText] = useState('');
  const [editNote, setEditNote] = useState('');

  // AI Co-evolution state
  const [evolvePrompt, setEvolvePrompt] = useState('');
  const [isEvolving, setIsEvolving] = useState(false);
  const [evolveError, setEvolveError] = useState<string | null>(null);

  // New task state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskAssignee, setNewTaskAssignee] = useState('');
  const [newTaskDue, setNewTaskDue] = useState('');

  // New feedback state
  const [feedbackFilter, setFeedbackFilter] = useState<'all' | FeedbackKind>('all');
  const [newFeedbackKind, setNewFeedbackKind] = useState<FeedbackKind>('progress');
  const [newFeedbackContent, setNewFeedbackContent] = useState('');

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const manualLeaveRef = useRef<boolean>(false);

  useEffect(() => {
    try {
      localStorage.setItem('inquiry-atelier-member-name', memberName);
      localStorage.setItem('inquiry-atelier-member-role', memberRole);
    } catch {
      // Ignore storage error
    }
  }, [memberName, memberRole]);

  useEffect(() => {
    if (initialRoomId && initialRoomId !== activeRoomId) {
      setActiveRoomId(initialRoomId);
      setJoinCodeInput(initialRoomId);
    }
  }, [initialRoomId, activeRoomId]);

  useEffect(() => {
    if (!room) return;
    if (!isEditingTopic) {
      setEditTitle(room.currentTopic.title);
      setEditQuestion(room.currentTopic.researchQuestion);
      setEditHypothesis(room.hypothesis);
      setEditDeliverable(room.currentTopic.deliverableFormat);
      setEditMethodologyText(room.currentTopic.methodology.join('\n'));
      setEditNote('');
    }
  }, [room, isEditingTopic]);

  // Connect WebSocket whenever activeRoomId changes
  useEffect(() => {
    if (!activeRoomId) {
      setRoom(null);
      setActiveMembers([]);
      setWsStatus('disconnected');
      return;
    }

    manualLeaveRef.current = false;
    let isCancelled = false;
    let attempt = 0;

    const loadInitialAndConnect = async () => {
      setIsLoadingRoom(true);
      setRoomError(null);
      try {
        const res = await fetch(`/api/rooms/${encodeURIComponent(activeRoomId)}`);
        const text = await res.text();
        let data: { room?: SharedInquiryRoom; activeMembers?: TeamMemberPresence[]; error?: string };
        try {
          data = JSON.parse(text);
        } catch {
          throw new Error(`서버 응답을 불러오지 못했습니다 (HTTP ${res.status}).`);
        }
        if (!res.ok || !data.room) {
          throw new Error(data.error || '협업방을 불러오지 못했습니다.');
        }
        if (isCancelled) return;
        setRoom(data.room);
        setActiveMembers(data.activeMembers || []);
        setIsLoadingRoom(false);
        connectSocket();
      } catch (err) {
        if (isCancelled) return;
        setIsLoadingRoom(false);
        setRoomError(err instanceof Error ? err.message : '협업방을 찾을 수 없습니다.');
        setActiveRoomId(null);
        onRoomChange(null);
      }
    };

    const connectSocket = () => {
      if (isCancelled || manualLeaveRef.current) return;
      setWsStatus('connecting');
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const socket = new WebSocket(`${protocol}//${window.location.host}/ws`);
      wsRef.current = socket;

      socket.onopen = () => {
        if (isCancelled) {
          socket.close();
          return;
        }
        attempt = 0;
        setWsStatus('connected');
        socket.send(
          JSON.stringify({
            type: 'room:join',
            roomId: activeRoomId,
            clientId,
            name: memberName,
            role: memberRole,
          })
        );
      };

      socket.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === 'room:sync') {
            setRoom(payload.room);
            setActiveMembers(payload.activeMembers || []);
          } else if (payload.type === 'presence:update') {
            setActiveMembers(payload.activeMembers || []);
          } else if (payload.type === 'room:error') {
            setRoomError(payload.message || '동기화 중 오류가 발생했습니다.');
          }
        } catch {
          // Ignore malformed frame
        }
      };

      socket.onclose = () => {
        if (isCancelled || manualLeaveRef.current) {
          setWsStatus('disconnected');
          return;
        }
        setWsStatus('connecting');
        const delay = Math.min(1000 * Math.pow(2, attempt), 8000);
        attempt += 1;
        reconnectTimerRef.current = window.setTimeout(connectSocket, delay);
      };
    };

    loadInitialAndConnect();

    return () => {
      isCancelled = true;
      manualLeaveRef.current = true;
      if (reconnectTimerRef.current !== null) {
        window.clearTimeout(reconnectTimerRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [activeRoomId, clientId]);

  const sendWs = (message: Record<string, unknown>) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    }
  };

  const handleUpdatePresenceIdentity = () => {
    if (!activeRoomId) return;
    sendWs({
      type: 'room:join',
      roomId: activeRoomId,
      clientId,
      name: memberName.trim() || '참여 학생',
      role: memberRole,
    });
  };

  const handleJoinRoomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = joinCodeInput.toUpperCase().trim();
    if (!cleaned) {
      setRoomError('입장할 6자리 초대 코드를 입력해 주세요.');
      return;
    }
    setRoomError(null);
    setActiveRoomId(cleaned);
    onRoomChange(cleaned);
  };

  const handleLeaveRoom = () => {
    manualLeaveRef.current = true;
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setActiveRoomId(null);
    setRoom(null);
    onRoomChange(null);
  };

  const handleCopyShare = async (mode: 'link' | 'code') => {
    if (!room) return;
    const text =
      mode === 'link'
        ? `${window.location.origin}${window.location.pathname}?room=${room.roomId}`
        : room.roomId;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedType(mode);
      setTimeout(() => setCopiedType(null), 1800);
    } catch {
      // Ignore clipboard failures
    }
  };

  const handleSaveManualTopicEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!room) return;
    const methodology = editMethodologyText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    sendWs({
      type: 'topic:update',
      roomId: room.roomId,
      clientId,
      authorName: memberName,
      patch: {
        title: editTitle,
        researchQuestion: editQuestion,
        hypothesis: editHypothesis,
        deliverableFormat: editDeliverable,
        methodology,
        note: editNote || '팀 기획 내용 직접 수정',
      },
    });
    setIsEditingTopic(false);
  };

  const handleAiEvolve = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!room || !evolvePrompt.trim()) return;
    setIsEvolving(true);
    setEvolveError(null);
    try {
      const res = await fetch(`/api/rooms/${encodeURIComponent(room.roomId)}/evolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: evolvePrompt.trim(),
          authorName: memberName,
        }),
      });
      const text = await res.text();
      let data: { room?: SharedInquiryRoom; error?: string };
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error(`서버 응답을 해석하지 못했습니다 (HTTP ${res.status}).`);
      }
      if (!res.ok || !data.room) {
        throw new Error(data.error || 'AI 주제 발전에 실패했습니다.');
      }
      setRoom(data.room);
      setEvolvePrompt('');
    } catch (err) {
      setEvolveError(err instanceof Error ? err.message : '오류가 발생했습니다.');
    } finally {
      setIsEvolving(false);
    }
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!room || !newTaskTitle.trim()) return;
    const task: TeamTask = {
      id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title: newTaskTitle.trim(),
      assignee: newTaskAssignee.trim() || memberName,
      dueLabel: newTaskDue.trim() || '진행 단계',
      status: 'todo',
      updatedBy: memberName,
      updatedAt: new Date().toISOString(),
    };
    sendWs({ type: 'task:create', roomId: room.roomId, task });
    setNewTaskTitle('');
    setNewTaskDue('');
  };

  const handleCycleTaskStatus = (task: TeamTask) => {
    if (!room) return;
    const order: TaskStatus[] = ['todo', 'in_progress', 'done'];
    const nextStatus = order[(order.indexOf(task.status) + 1) % order.length];
    sendWs({
      type: 'task:update',
      roomId: room.roomId,
      taskId: task.id,
      patch: { status: nextStatus, updatedBy: memberName },
    });
  };

  const handleUpdateTaskAssignee = (taskId: string, assignee: string) => {
    if (!room) return;
    sendWs({
      type: 'task:update',
      roomId: room.roomId,
      taskId,
      patch: { assignee, updatedBy: memberName },
    });
  };

  const handleDeleteTask = (taskId: string) => {
    if (!room) return;
    sendWs({ type: 'task:delete', roomId: room.roomId, taskId });
  };

  const handleCreateFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!room || !newFeedbackContent.trim()) return;
    const entry: FeedbackEntry = {
      id: `fb-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      authorName: memberName,
      authorRole: memberRole,
      kind: newFeedbackKind,
      content: newFeedbackContent.trim(),
      createdAt: new Date().toISOString(),
      likes: [],
      resolved: false,
    };
    sendWs({ type: 'feedback:create', roomId: room.roomId, entry });
    setNewFeedbackContent('');
  };

  const handleToggleLike = (entryId: string) => {
    if (!room) return;
    sendWs({
      type: 'feedback:toggle_like',
      roomId: room.roomId,
      entryId,
      actorName: memberName,
    });
  };

  const handleToggleResolve = (entryId: string) => {
    if (!room) return;
    sendWs({ type: 'feedback:toggle_resolve', roomId: room.roomId, entryId });
  };

  const progressStats = useMemo(() => {
    if (!room || room.tasks.length === 0) {
      return { total: 0, done: 0, inProgress: 0, percent: 0 };
    }
    const done = room.tasks.filter((t) => t.status === 'done').length;
    const inProgress = room.tasks.filter((t) => t.status === 'in_progress').length;
    const percent = Math.round((done / room.tasks.length) * 100);
    return { total: room.tasks.length, done, inProgress, percent };
  }, [room]);

  const filteredFeedbacks = useMemo(() => {
    if (!room) return [];
    const list = [...room.feedbacks].reverse();
    if (feedbackFilter === 'all') return list;
    return list.filter((f) => f.kind === feedbackFilter);
  }, [room, feedbackFilter]);

  if (isLoadingRoom) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-3">
        <Loader2 className="w-6 h-6 animate-spin text-blue-800 mx-auto" />
        <p className="text-sm font-medium text-slate-700">팀 탐구 협업방을 불러오고 있습니다...</p>
      </div>
    );
  }

  // Entry Screen when no room is active
  if (!room) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">내 프로필 및 초대 코드 입장</h2>
            <p className="text-sm text-slate-500 mt-1">
              친구에게 받은 초대 코드로 입장하면 실시간으로 탐구 주제를 함께 발전시키고 진행 상황을 공유할 수 있습니다.
            </p>
          </div>

          <div className="pt-4 border-t border-slate-200 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="collab-name" className="block text-xs font-medium text-slate-600 mb-1">
                  내 이름 (닉네임)
                </label>
                <input
                  id="collab-name"
                  type="text"
                  value={memberName}
                  onChange={(e) => setMemberName(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                />
              </div>
              <div>
                <label htmlFor="collab-role" className="block text-xs font-medium text-slate-600 mb-1">
                  팀 내 희망 역할
                </label>
                <select
                  id="collab-role"
                  value={memberRole}
                  onChange={(e) => setMemberRole(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                >
                  {ROLE_OPTIONS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <form onSubmit={handleJoinRoomSubmit} className="space-y-3">
              <div>
                <label htmlFor="room-code-input" className="block text-xs font-medium text-slate-600 mb-1">
                  6자리 협업방 초대 코드
                </label>
                <div className="flex gap-2">
                  <input
                    id="room-code-input"
                    type="text"
                    value={joinCodeInput}
                    onChange={(e) => setJoinCodeInput(e.target.value.toUpperCase())}
                    placeholder="예: DEMO22"
                    maxLength={8}
                    className="flex-1 rounded-lg border border-slate-300 px-3.5 py-2 text-sm font-mono-tabular uppercase tracking-wider text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-blue-800 hover:bg-blue-900 text-white text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer"
                  >
                    입장하기
                  </button>
                </div>
              </div>
              {roomError && (
                <p role="alert" className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                  {roomError}
                </p>
              )}
            </form>
          </div>
        </div>

        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-slate-900">팀 탐구 협업방에서 할 수 있는 일</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              추천받은 탐구 주제를 1인 수행평가에서 끝내지 않고, 친구들과 함께 실시간으로 기획하고 완성도를 높일 수 있습니다.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4 border-t border-slate-200">
            <div className="space-y-1.5">
              <div className="text-xs font-mono-tabular font-semibold text-blue-800">01. 공동 주제 발전</div>
              <p className="text-sm font-semibold text-slate-900">주제·가설 실시간 편집</p>
              <p className="text-xs text-slate-600 leading-relaxed">
                팀원들의 피드백을 반영해 탐구 질문과 가설을 수정하거나 AI 공동 발전 도우미로 업그레이드합니다.
              </p>
            </div>
            <div className="space-y-1.5">
              <div className="text-xs font-mono-tabular font-semibold text-blue-800">02. 역할·진행 동기화</div>
              <p className="text-sm font-semibold text-slate-900">마일스톤 실시간 체크</p>
              <p className="text-xs text-slate-600 leading-relaxed">
                단계별 담당자를 배정하고 완료 상태를 누르면 모든 팀원 화면에 진행률이 즉시 반영됩니다.
              </p>
            </div>
            <div className="space-y-1.5">
              <div className="text-xs font-mono-tabular font-semibold text-blue-800">03. 상호 피드백</div>
              <p className="text-sm font-semibold text-slate-900">진행 상황 &amp; 질문 공유</p>
              <p className="text-xs text-slate-600 leading-relaxed">
                자료 조사 진행 상황과 보완 의견을 실시간으로 주고받고 해결 여부를 체크합니다.
              </p>
            </div>
          </div>

          <div className="pt-5 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-0.5">
              <p className="text-sm font-semibold text-slate-900">실시간 협업방 바로 체험해 보기</p>
              <p className="text-xs text-slate-500">
                샘플 팀 프로젝트(코드 <span className="font-mono-tabular font-semibold text-slate-800">DEMO22</span> · 확률과 통계 × 컴퓨터공학)에 바로 입장합니다.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onGoRecommend}
                className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                새 주제 추천부터 받기
              </button>
              <button
                type="button"
                onClick={() => {
                  setJoinCodeInput('DEMO22');
                  setActiveRoomId('DEMO22');
                  onRoomChange('DEMO22');
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-800 hover:bg-blue-900 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                <Users className="w-3.5 h-3.5" />
                <span>샘플 협업방(DEMO22) 열기</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Room Header & Presence Strip */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1.5 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-500 font-medium">
              <span className="font-mono-tabular font-semibold text-blue-800">
                협업방 코드 {room.roomId}
              </span>
              <span aria-hidden="true">·</span>
              <span>{room.gradeLevel}</span>
              <span aria-hidden="true">·</span>
              <span>{room.subject}</span>
              <span aria-hidden="true">·</span>
              <span>{room.assessmentType}</span>
              <span aria-hidden="true">·</span>
              <span>{room.targetMajor}</span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1.5">
                <span
                  className={`w-2 h-2 rounded-full ${
                    wsStatus === 'connected'
                      ? 'bg-emerald-600'
                      : wsStatus === 'connecting'
                        ? 'bg-amber-500 animate-pulse'
                        : 'bg-slate-400'
                  }`}
                />
                <span>
                  {wsStatus === 'connected'
                    ? '실시간 동기화 연결됨'
                    : wsStatus === 'connecting'
                      ? '실시간 연결 중...'
                      : '연결 대기'}
                </span>
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 leading-snug">{room.currentTopic.title}</h2>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => handleCopyShare('code')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200/80 px-3 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              {copiedType === 'code' ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedType === 'code' ? '코드 복사됨' : `코드 ${room.roomId}`}</span>
            </button>
            <button
              type="button"
              onClick={() => handleCopyShare('link')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-white bg-blue-800 hover:bg-blue-900 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              {copiedType === 'link' ? <Check className="w-3.5 h-3.5" /> : <Link2 className="w-3.5 h-3.5" />}
              <span>{copiedType === 'link' ? '초대 링크 복사됨' : '친구 초대 링크 복사'}</span>
            </button>
            <button
              type="button"
              onClick={handleLeaveRoom}
              className="inline-flex items-center gap-1 text-xs font-medium text-slate-600 hover:text-red-700 px-2.5 py-2 rounded-lg hover:bg-red-50 transition-colors whitespace-nowrap cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>나가기</span>
            </button>
          </div>
        </div>

        {/* Presence & Identity Row + Progress Meter */}
        <div className="pt-4 border-t border-slate-200 grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
          <div className="lg:col-span-7 flex flex-wrap items-center gap-3">
            <span className="text-xs font-semibold text-slate-500 whitespace-nowrap">
              현재 접속 팀원 (<span className="font-mono-tabular">{activeMembers.length}</span>명):
            </span>
            <div className="flex flex-wrap items-center gap-3">
              {activeMembers.map((m) => (
                <div key={m.clientId} className="inline-flex items-center gap-1.5 text-xs text-slate-800">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: m.color }}
                  />
                  <span className="font-semibold">{m.name}</span>
                  <span className="text-slate-500">({m.role})</span>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-1.5 ml-auto sm:ml-2">
              <input
                type="text"
                value={memberName}
                onChange={(e) => setMemberName(e.target.value)}
                onBlur={handleUpdatePresenceIdentity}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.currentTarget.blur();
                  }
                }}
                aria-label="내 표시 이름"
                className="w-20 rounded-md border border-slate-200 px-2 py-1 text-xs text-slate-800 focus:outline-none focus:border-blue-700"
              />
              <select
                value={memberRole}
                onChange={(e) => {
                  setMemberRole(e.target.value);
                  sendWs({
                    type: 'room:join',
                    roomId: room.roomId,
                    clientId,
                    name: memberName,
                    role: e.target.value,
                  });
                }}
                aria-label="내 역할"
                className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700 focus:outline-none focus:border-blue-700"
              >
                {ROLE_OPTIONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700">팀 프로젝트 전체 진행률</span>
              <span className="font-mono-tabular font-semibold text-blue-800">
                완료 {progressStats.done} / {progressStats.total}단계 ({progressStats.percent}%)
              </span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-800 transition-all duration-300"
                style={{ width: `${progressStats.percent}%` }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Workspace Sub-Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="inline-flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
          <button
            type="button"
            onClick={() => setSubTab('evolve')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              subTab === 'evolve' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            주제 공동 발전 · 기획
          </button>
          <button
            type="button"
            onClick={() => setSubTab('tasks')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              subTab === 'tasks' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            역할 분담 · 진행 현황 (<span className="font-mono-tabular">{progressStats.done}/{progressStats.total}</span>)
          </button>
          <button
            type="button"
            onClick={() => setSubTab('feedback')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              subTab === 'feedback' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            실시간 진행 공유 · 피드백 (<span className="font-mono-tabular">{room.feedbacks.length}</span>)
          </button>
        </div>
      </div>

      {/* Sub-Tab 1: Co-evolution & Team Planning */}
      {subTab === 'evolve' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-semibold text-slate-900">공동 탐구 기획서</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  수정 사항은 연결된 모든 팀원에게 즉시 동기화되며 개정 이력에 기록됩니다.
                </p>
              </div>
              {!isEditingTopic && (
                <button
                  type="button"
                  onClick={() => setIsEditingTopic(true)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>직접 편집</span>
                </button>
              )}
            </div>

            {isEditingTopic ? (
              <form onSubmit={handleSaveManualTopicEdit} className="space-y-4 pt-4 border-t border-slate-200">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">탐구 주제명</label>
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">핵심 탐구 질문</label>
                  <textarea
                    rows={2}
                    value={editQuestion}
                    onChange={(e) => setEditQuestion(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">팀 탐구 가설</label>
                  <textarea
                    rows={2}
                    value={editHypothesis}
                    onChange={(e) => setEditHypothesis(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    단계별 수행 절차 (줄바꿈으로 단계 구분)
                  </label>
                  <textarea
                    rows={4}
                    value={editMethodologyText}
                    onChange={(e) => setEditMethodologyText(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">산출물 전략</label>
                  <input
                    type="text"
                    value={editDeliverable}
                    onChange={(e) => setEditDeliverable(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">수정 메모 (이력 기록용)</label>
                  <input
                    type="text"
                    value={editNote}
                    onChange={(e) => setEditNote(e.target.value)}
                    placeholder="예: 실험 대조군 조건을 더 구체적으로 좁힘"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                  />
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsEditingTopic(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                  >
                    취소
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-semibold text-white bg-blue-800 hover:bg-blue-900 rounded-lg cursor-pointer"
                  >
                    변경사항 팀 전체에 반영
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-5 pt-4 border-t border-slate-200">
                <div className="space-y-1">
                  <span className="text-xs font-semibold text-slate-500">핵심 탐구 질문</span>
                  <p className="text-sm text-slate-800 leading-relaxed">{room.currentTopic.researchQuestion}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-xs font-semibold text-slate-500">팀 탐구 가설</span>
                  <p className="text-sm text-slate-800 leading-relaxed">{room.hypothesis}</p>
                </div>
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-slate-500">공동 탐구 수행 단계</span>
                  <ol className="space-y-2">
                    {room.currentTopic.methodology.map((step, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-sm text-slate-700 leading-relaxed">
                        <span className="font-mono-tabular text-xs font-semibold text-blue-800 pt-0.5 shrink-0">
                          0{i + 1}
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
                <div className="pt-3 border-t border-slate-200 space-y-1">
                  <span className="text-xs font-semibold text-slate-500">목표 산출물 구성</span>
                  <p className="text-sm text-slate-700">{room.currentTopic.deliverableFormat}</p>
                </div>
              </div>
            )}
          </div>

          {/* Right side: AI Co-Evolution + Version History */}
          <div className="lg:col-span-5 space-y-6">
            <form
              onSubmit={handleAiEvolve}
              className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-800 shrink-0" />
                <h3 className="text-base font-semibold text-slate-900">AI로 팀 주제 함께 발전시키기</h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                최근 팀원들이 남긴 피드백과 요청 방향을 반영해 AI가 주제·가설·수행 단계를 한 단계 더 정교하게 다듬고 모든 팀원에게 즉시 공유합니다.
              </p>
              <textarea
                rows={3}
                value={evolvePrompt}
                onChange={(e) => setEvolvePrompt(e.target.value)}
                placeholder="예: 데이터 시각화 단계를 구체화하고, 고교 수준에서 검증 가능한 대조군 기준을 추가해 주세요."
                className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
              />
              {evolveError && (
                <p className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                  {evolveError}
                </p>
              )}
              <button
                type="submit"
                disabled={isEvolving || !evolvePrompt.trim()}
                className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white text-xs sm:text-sm font-semibold py-2.5 px-4 transition-colors cursor-pointer disabled:cursor-not-allowed"
              >
                {isEvolving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>팀 피드백 반영해 주제 발전 중...</span>
                  </>
                ) : (
                  <span>AI 공동 발전안 반영하기</span>
                )}
              </button>
            </form>

            <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-slate-600" />
                <h3 className="text-sm font-semibold text-slate-900">
                  주제 발전 이력 (<span className="font-mono-tabular">{room.revisions.length}</span>)
                </h3>
              </div>
              <div className="divide-y divide-slate-200 max-h-72 overflow-y-auto pr-1">
                {[...room.revisions].reverse().map((rev) => (
                  <div key={rev.version} className="py-3 first:pt-0 last:pb-0 space-y-1">
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="font-mono-tabular font-semibold text-blue-800">v{rev.version}</span>
                      <span className="font-mono-tabular">
                        {new Date(rev.updatedAt).toLocaleTimeString('ko-KR', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="text-xs font-semibold text-slate-800">{rev.updatedBy}</p>
                    <p className="text-xs text-slate-600 leading-relaxed">{rev.note}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Team Task Board & Live Progress */}
      {subTab === 'tasks' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-semibold text-slate-900">팀 역할 분담 및 실시간 진행 보드</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                상태 버튼을 클릭하면 대기 → 진행 중 → 완료로 순환하며 팀 전체 진행률에 즉시 반영됩니다.
              </p>
            </div>
          </div>

          <form
            onSubmit={handleAddTask}
            className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 pt-4 border-t border-slate-200"
          >
            <input
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="새 팀 작업 내용 입력 (예: 설문 문항 10개 초안 작성 및 검토)"
              className="sm:col-span-6 rounded-lg border border-slate-300 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-blue-700"
            />
            <input
              type="text"
              value={newTaskAssignee}
              onChange={(e) => setNewTaskAssignee(e.target.value)}
              placeholder={`담당자 (기본: ${memberName})`}
              className="sm:col-span-2 rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-blue-700"
            />
            <input
              type="text"
              value={newTaskDue}
              onChange={(e) => setNewTaskDue(e.target.value)}
              placeholder="단계/마감 (예: 금주 수요일)"
              className="sm:col-span-2 rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-blue-700"
            />
            <button
              type="submit"
              disabled={!newTaskTitle.trim()}
              className="sm:col-span-2 inline-flex items-center justify-center gap-1.5 rounded-lg bg-blue-800 hover:bg-blue-900 disabled:bg-slate-300 text-white text-sm font-semibold py-2 px-3 transition-colors whitespace-nowrap cursor-pointer disabled:cursor-not-allowed"
            >
              <Plus className="w-4 h-4" />
              <span>추가</span>
            </button>
          </form>

          <div className="divide-y divide-slate-200 border-t border-slate-200">
            {room.tasks.length === 0 ? (
              <div className="py-10 text-center text-sm text-slate-500">
                아직 등록된 작업이 없습니다. 위 입력창에서 팀원의 첫 역할을 등록해 보세요.
              </div>
            ) : (
              room.tasks.map((task) => {
                const meta = STATUS_META[task.status];
                return (
                  <div
                    key={task.id}
                    className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <button
                        type="button"
                        onClick={() => handleCycleTaskStatus(task)}
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${meta.colorClass}`}
                        title="클릭하여 진행 상태 변경"
                      >
                        {task.status === 'done' ? (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        ) : task.status === 'in_progress' ? (
                          <Clock className="w-3.5 h-3.5" />
                        ) : (
                          <Circle className="w-3.5 h-3.5" />
                        )}
                        <span>{meta.label}</span>
                      </button>

                      <div className="space-y-0.5 min-w-0">
                        <p
                          className={`text-sm font-medium ${
                            task.status === 'done' ? 'line-through text-slate-400' : 'text-slate-900'
                          }`}
                        >
                          {task.title}
                        </p>
                        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                          <span>기한: {task.dueLabel}</span>
                          <span aria-hidden="true">·</span>
                          <span>최근 업데이트: {task.updatedBy}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                      <input
                        key={`${task.id}-${task.assignee}`}
                        type="text"
                        defaultValue={task.assignee}
                        onBlur={(e) => {
                          if (e.target.value !== task.assignee) {
                            handleUpdateTaskAssignee(task.id, e.target.value);
                          }
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.currentTarget.blur();
                          }
                        }}
                        aria-label="담당자"
                        className="w-24 rounded-md border border-slate-200 px-2.5 py-1 text-xs text-slate-800 focus:outline-none focus:border-blue-700"
                      />
                      <button
                        type="button"
                        onClick={() => handleDeleteTask(task.id)}
                        aria-label="작업 삭제"
                        className="p-1.5 text-slate-400 hover:text-red-700 rounded-lg hover:bg-red-50 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Real-time Progress Log & Peer Feedback */}
      {subTab === 'feedback' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={handleCreateFeedback}
            className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4"
          >
            <div className="flex items-center gap-2">
              <MessageSquarePlus className="w-4 h-4 text-blue-800" />
              <h3 className="text-base font-semibold text-slate-900">진행 상황 공유 · 피드백 남기기</h3>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              {(Object.keys(KIND_LABELS) as FeedbackKind[]).map((kind) => {
                const active = newFeedbackKind === kind;
                return (
                  <button
                    key={kind}
                    type="button"
                    onClick={() => setNewFeedbackKind(kind)}
                    className={`py-2 px-2.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap cursor-pointer ${
                      active
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {KIND_LABELS[kind]}
                  </button>
                );
              })}
            </div>

            <textarea
              rows={4}
              value={newFeedbackContent}
              onChange={(e) => setNewFeedbackContent(e.target.value)}
              placeholder="오늘 진행한 자료 조사 내용, 실험 결과, 또는 팀원의 초안에 대한 구체적인 피드백을 남겨 주세요."
              className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-700/20 focus:border-blue-700"
            />

            <button
              type="submit"
              disabled={!newFeedbackContent.trim()}
              className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-blue-800 hover:bg-blue-900 disabled:bg-slate-300 text-white text-sm font-semibold py-2.5 px-4 transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
              <span>팀 피드에 실시간 등록</span>
            </button>
          </form>

          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-base font-semibold text-slate-900">팀 피드백 · 진행 타임라인</h3>
              <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setFeedbackFilter('all')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    feedbackFilter === 'all' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                  }`}
                >
                  전체
                </button>
                {(Object.keys(KIND_LABELS) as FeedbackKind[]).map((kind) => (
                  <button
                    key={kind}
                    type="button"
                    onClick={() => setFeedbackFilter(kind)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                      feedbackFilter === kind ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                    }`}
                  >
                    {KIND_LABELS[kind]}
                  </button>
                ))}
              </div>
            </div>

            <div className="divide-y divide-slate-200 border-t border-slate-200">
              {filteredFeedbacks.length === 0 ? (
                <div className="py-10 text-center text-sm text-slate-500">
                  해당 유형의 진행 공유나 피드백이 아직 없습니다.
                </div>
              ) : (
                filteredFeedbacks.map((entry) => {
                  const likedByMe = entry.likes.includes(memberName);
                  return (
                    <div key={entry.id} className="py-4 space-y-2.5">
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-slate-900">{entry.authorName}</span>
                          <span aria-hidden="true">·</span>
                          <span>{entry.authorRole}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-blue-800">{KIND_LABELS[entry.kind]}</span>
                          {entry.resolved && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-semibold text-emerald-700">반영 완료</span>
                            </>
                          )}
                        </div>
                        <span className="font-mono-tabular">
                          {new Date(entry.createdAt).toLocaleTimeString('ko-KR', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      <p
                        className={`text-sm leading-relaxed ${
                          entry.resolved ? 'text-slate-500' : 'text-slate-800'
                        }`}
                      >
                        {entry.content}
                      </p>

                      <div className="flex items-center gap-3 pt-1">
                        <button
                          type="button"
                          onClick={() => handleToggleLike(entry.id)}
                          className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-md border transition-colors cursor-pointer ${
                            likedByMe
                              ? 'bg-blue-50 text-blue-800 border-blue-200'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <ThumbsUp className="w-3 h-3" />
                          <span className="font-mono-tabular">공감 {entry.likes.length}</span>
                        </button>

                        {(entry.kind === 'feedback' || entry.kind === 'question') && (
                          <button
                            type="button"
                            onClick={() => handleToggleResolve(entry.id)}
                            className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-md border transition-colors cursor-pointer ${
                              entry.resolved
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{entry.resolved ? '반영됨' : '반영 완료로 표시'}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
