import { AssessmentType, GradeLevel, InquiryRequest } from '../types/inquiry';

export const GRADE_LEVELS: GradeLevel[] = [
  '고1 공통',
  '고2 일반선택',
  '고3 진로·융합선택',
];

export const ASSESSMENT_TYPES: AssessmentType[] = [
  '탐구 보고서',
  '발표·PPT',
  '실험·실습',
  '코딩·데이터 분석',
  '토론·논술',
  '프로젝트·제작',
];

export const SUBJECT_PRESETS: Record<GradeLevel, string[]> = {
  '고1 공통': [
    '통합과학',
    '과학탐구실험',
    '통합사회',
    '공통수학',
    '공통국어',
    '공통영어',
    '정보',
  ],
  '고2 일반선택': [
    '대수',
    '미적분Ⅰ',
    '확률과 통계',
    '물리학',
    '화학',
    '생명과학',
    '지구과학',
    '현대사회와 윤리',
    '세계시민과 지리',
    '사회와 문화',
    '정보',
  ],
  '고3 진로·융합선택': [
    '미적분Ⅱ',
    '기하',
    '인공지능 수학',
    '경제 수학',
    '역학과 에너지',
    '물질과 에너지',
    '세포와 물질대사',
    '기후변화와 지속가능한 세계',
    '사회문제 탐구',
    '인공지능 기초',
    '데이터 과학',
  ],
};

export const MAJOR_PRESETS: string[] = [
  '컴퓨터공학·AI',
  '의예·치의·약학',
  '생명공학·바이오',
  '경영·경제·금융',
  '기계·로봇·항공',
  '화학·신소재공학',
  '환경·에너지공학',
  '교육·심리학',
  '미디어·사회학',
  '법학·행정·정치외교',
];

export const COMPETENCY_OPTIONS: string[] = [
  '수리·논리적 모델링',
  '데이터 분석·SW 구현',
  '실험 설계 및 오차 분석',
  '비판적 문헌·사료 비평',
  '학제간 융합 사고',
  '문제 해결 및 정책 제언',
  '공동체·윤리적 성찰',
  '시각화 및 발표 소통력',
];

export interface QuickScenario {
  label: string;
  subtitle: string;
  request: InquiryRequest;
}

export const QUICK_SCENARIOS: QuickScenario[] = [
  {
    label: '확률·통계 × 컴퓨터공학',
    subtitle: '베이즈 정리와 AI 스팸·의료 오진율 분석',
    request: {
      topic: '조건부 확률과 베이즈 정리를 활용한 알고리즘 예측 신뢰도 분석',
      subject: '확률과 통계',
      gradeLevel: '고2 일반선택',
      assessmentType: '코딩·데이터 분석',
      conditions: 'A4 4쪽 이내 탐구 보고서, 파이썬 시뮬레이션 또는 스프레드시트 수치 검증 포함, 개인 탐구',
      targetMajor: '컴퓨터공학·AI',
      competencies: ['수리·논리적 모델링', '데이터 분석·SW 구현', '시각화 및 발표 소통력'],
      additionalFocus: '단순 공식 대입을 넘어 실제 불균형 데이터셋에서 위양성 문제를 수학적으로 해석하고 싶습니다.',
    },
  },
  {
    label: '통합과학 × 환경·바이오',
    subtitle: '미세플라스틱과 생태계 독성·정화 메커니즘',
    request: {
      topic: '생활 속 미세플라스틱 유출 경로와 생분해성 대체 소재의 분해 효율 비교',
      subject: '통합과학',
      gradeLevel: '고1 공통',
      assessmentType: '실험·실습',
      conditions: '학교 과학실 보유 기구(현미경, pH 미터, 항온수조) 활용 가능, 2인 1조 2주 탐구',
      targetMajor: '환경·에너지공학',
      competencies: ['실험 설계 및 오차 분석', '공동체·윤리적 성찰', '문제 해결 및 정책 제언'],
      additionalFocus: '대조군 설정이 명확하고 고등학생 수준에서 정량적 관찰이 가능한 탐구를 원합니다.',
    },
  },
  {
    label: '사회문제 탐구 × 경영·경제',
    subtitle: '플랫폼 다크패턴과 소비자 행동경제학',
    request: {
      topic: '온라인 구독 플랫폼의 다크패턴 설계가 청소년 소비 의사결정에 미치는 영향',
      subject: '사회문제 탐구',
      gradeLevel: '고3 진로·융합선택',
      assessmentType: '탐구 보고서',
      conditions: '교내 학생 60명 이상 설문조사 및 통계 분석 포함, 10분 구술 발표 병행',
      targetMajor: '경영·경제·금융',
      competencies: ['비판적 문헌·사료 비평', '데이터 분석·SW 구현', '문제 해결 및 정책 제언'],
      additionalFocus: '행동경제학의 넛지·손실회피 이론과 공정거래법 규제 이슈를 균형 있게 다루고 싶습니다.',
    },
  },
];
