import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

interface VercelLikeRequest {
  method?: string;
  body?: unknown;
}

interface VercelLikeResponse {
  status: (code: number) => VercelLikeResponse;
  json: (payload: unknown) => void;
}

function formatError(error: unknown): { status: number; message: string } {
  if (error instanceof Error && error.message === 'MISSING_API_KEY') {
    return {
      status: 500,
      message: 'GEMINI_API_KEY가 설정되지 않았습니다. Vercel Project Settings > Environment Variables에 GEMINI_API_KEY를 추가해 주세요.',
    };
  }
  const errObj = error as { status?: number; message?: string };
  const rawMessage = errObj?.message || '알 수 없는 오류가 발생했습니다.';
  const status = typeof errObj?.status === 'number' ? errObj.status : 500;

  if (status === 403 || rawMessage.includes('PERMISSION_DENIED') || rawMessage.includes('API_KEY_INVALID')) {
    return {
      status: 403,
      message: 'Gemini API 키 인증에 실패했습니다. 설정된 GEMINI_API_KEY를 확인해 주세요.',
    };
  }
  if (status === 429 || rawMessage.includes('RESOURCE_EXHAUSTED')) {
    return {
      status: 429,
      message: '요청 한도를 초과했습니다. 잠시 후 다시 시도해 주세요.',
    };
  }
  return {
    status: status >= 400 && status < 600 ? status : 500,
    message: `탐구 주제를 생성하는 중 오류가 발생했습니다: ${rawMessage}`,
  };
}

export default async function handler(req: VercelLikeRequest, res: VercelLikeResponse) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      throw new Error('MISSING_API_KEY');
    }

    const body = (typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {}) as {
      topic?: string;
      subject?: string;
      gradeLevel?: string;
      assessmentType?: string;
      conditions?: string;
      targetMajor?: string;
      competencies?: string[];
      additionalFocus?: string;
    };

    const topic = (body.topic || '').trim();
    const subject = (body.subject || '').trim();
    const gradeLevel = body.gradeLevel || '고2 일반선택';
    const assessmentType = body.assessmentType || '탐구 보고서';
    const conditions = (body.conditions || '').trim();
    const targetMajor = (body.targetMajor || '').trim();
    const competencies = Array.isArray(body.competencies) ? body.competencies : [];
    const additionalFocus = (body.additionalFocus || '').trim();

    if (!topic) {
      res.status(400).json({ error: '탐구 주제 또는 관심 키워드를 입력해 주세요.' });
      return;
    }

    if (!targetMajor) {
      res.status(400).json({ error: '지망학과 또는 진로 희망 분야를 입력해 주세요.' });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = `당신은 대한민국 '2022 개정 교육과정' 및 고교학점제, 학생부종합전형 교과 세특(세부능력 및 특기사항) 설계에 정통한 고등학교 수석 진로·진학 탐구 컨설턴트입니다.

학생이 입력한 주제, 수행평가 조건, 지망학과, 보여주고 싶은 역량을 종합 분석하여, 실제로 고등학교 수준에서 수행 가능하면서도 학업적 깊이와 전공 적합성이 돋보이는 **3개의 차별화된 탐구 주제**를 추천하세요.

반드시 지켜야 할 원칙:
1. **3개 주제의 관점 다각화**: 교과 핵심 개념 심화·원리 탐구형 / 실증 데이터 분석·실험/구현 중심형 / 학제간 융합·사회적/윤리적 대안 제언형
2. **2022 개정 교육과정 정합성**: 2022 개정 교육과정 교과 체계의 실제 단원 개념과 자연스럽게 연결하세요.
3. **현실적이고 솔직한 장단점 분석**: 장점(2~3개)과 현실적 한계 및 보완 전략(2~3개)을 구체적으로 작성하세요.
4. **이어갈 수 있는 후속 탐구(followUps) 설계**: 각 주제마다 다음 학기/학년의 다른 2022 개정 선택 과목과 연결되는 2개 이상의 후속 탐구를 제안하세요.
5. **수행평가 조건 준수**: 평가 유형(${assessmentType})과 세부 조건 안에서 실행 가능한 방법과 산출물을 제안하세요.
6. 한국어로 작성하며 허위 URL이나 존재하지 않는 논문 제목을 지어내지 마세요.`;

    const userPrompt = `다음 학생의 탐구 설계 요청에 맞춰 3개의 탐구 주제를 추천해 주세요.

- 관심 주제/키워드: ${topic}
- 관련 교과목: ${subject || '학생 입력 주제에 가장 적합한 2022 개정 교과목 자동 매칭'}
- 학년·과정 수준: ${gradeLevel}
- 수행평가 유형: ${assessmentType}
- 세부 조건 및 제약사항: ${conditions || '특별한 제약 없음 (고등학교 정규 수업·수행평가 범위 내)'}
- 지망학과: ${targetMajor}
- 보여주고 싶은 역량: ${competencies.length > 0 ? competencies.join(', ') : '학업적 탐구력, 전공 연계성, 논리적 사고력'}
- 추가 어필 포인트: ${additionalFocus || '없음'}`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: userPrompt,
      config: {
        systemInstruction,
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.MEDIUM,
        },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            advisorSummary: { type: Type.STRING },
            topics: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  approachType: { type: Type.STRING },
                  title: { type: Type.STRING },
                  researchQuestion: { type: Type.STRING },
                  curriculumConnection: { type: Type.STRING },
                  methodology: { type: Type.ARRAY, items: { type: Type.STRING } },
                  deliverableFormat: { type: Type.STRING },
                  pros: { type: Type.ARRAY, items: { type: Type.STRING } },
                  cons: { type: Type.ARRAY, items: { type: Type.STRING } },
                  competencyAlignment: { type: Type.STRING },
                  difficulty: { type: Type.STRING, enum: ['기초·안정', '심화·도전', '융합·확장'] },
                  estimatedHours: { type: Type.STRING },
                  followUps: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        title: { type: Type.STRING },
                        linkedSubject: { type: Type.STRING },
                        direction: { type: Type.STRING },
                        storylineNote: { type: Type.STRING },
                      },
                      required: ['title', 'linkedSubject', 'direction', 'storylineNote'],
                    },
                  },
                },
                required: [
                  'id',
                  'approachType',
                  'title',
                  'researchQuestion',
                  'curriculumConnection',
                  'methodology',
                  'deliverableFormat',
                  'pros',
                  'cons',
                  'competencyAlignment',
                  'difficulty',
                  'estimatedHours',
                  'followUps',
                ],
              },
            },
          },
          required: ['advisorSummary', 'topics'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim());
    if (!parsed || !Array.isArray(parsed.topics) || parsed.topics.length === 0) {
      throw new Error('AI 응답 형식이 올바르지 않습니다. 다시 시도해 주세요.');
    }

    res.status(200).json(parsed);
  } catch (error) {
    const formatted = formatError(error);
    res.status(formatted.status).json({ error: formatted.message });
  }
}
