import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

interface VercelLikeRequest {
  method?: string;
  body?: unknown;
}

interface VercelLikeResponse {
  status: (code: number) => VercelLikeResponse;
  json: (payload: unknown) => void;
}

function formatError(error: unknown): { status: number; message: string } {
  if (error instanceof Error && error.message === 'MISSING_API_KEY') {
    return {
      status: 500,
      message: 'GEMINI_API_KEY가 설정되지 않았습니다. Vercel Project Settings > Environment Variables에 GEMINI_API_KEY를 추가해 주세요.',
    };
  }
  const errObj = error as { status?: number; message?: string };
  const rawMessage = errObj?.message || '알 수 없는 오류가 발생했습니다.';
  const status = typeof errObj?.status === 'number' ? errObj.status : 500;
  return {
    status: status >= 400 && status < 600 ? status : 500,
    message: `상세 계획서 생성 중 오류가 발생했습니다: ${rawMessage}`,
  };
}

export default async function handler(req: VercelLikeRequest, res: VercelLikeResponse) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      throw new Error('MISSING_API_KEY');
    }

    const body = (typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {}) as {
      topicData?: {
        title?: string;
        researchQuestion?: string;
        curriculumConnection?: string;
        methodology?: string[];
      };
      requestContext?: {
        assessmentType?: string;
        conditions?: string;
        targetMajor?: string;
      };
    };

    const topicData = body.topicData;
    const requestContext = body.requestContext;

    if (!topicData || !topicData.title) {
      res.status(400).json({ error: '계획서를 생성할 탐구 주제 정보가 필요합니다.' });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `다음 고등학생 탐구 주제에 대해 바로 보고서나 발표 준비에 착수할 수 있는 구체적인 탐구 계획서 아웃라인을 작성해 주세요.

- 주제명: ${topicData.title}
- 핵심 탐구 질문: ${topicData.researchQuestion || ''}
- 연계 교과: ${topicData.curriculumConnection || ''}
- 수행평가 유형: ${requestContext?.assessmentType || '탐구 보고서'}
- 세부 조건: ${requestContext?.conditions || '표준 수행평가'}
- 지망학과: ${requestContext?.targetMajor || '관련 전공'}
- 탐구 방법 요약: ${(topicData.methodology || []).join(' / ')}`,
      config: {
        systemInstruction:
          '당신은 2022 개정 교육과정 고등학교 탐구 멘토입니다. 가설, 4~5단계 상세 목차, 활용 가능한 공신력 있는 자료/도구, 수행평가 자체 점검 체크리스트, 학술 검색 키워드를 JSON으로 제공하세요. 허위 URL이나 가짜 논문 제목을 만들지 마세요.',
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.LOW,
        },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            hypothesis: { type: Type.STRING },
            tableOfContents: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  section: { type: Type.STRING },
                  details: { type: Type.STRING },
                },
                required: ['section', 'details'],
              },
            },
            dataAndTools: { type: Type.ARRAY, items: { type: Type.STRING } },
            evaluationChecklist: { type: Type.ARRAY, items: { type: Type.STRING } },
            searchKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ['hypothesis', 'tableOfContents', 'dataAndTools', 'evaluationChecklist', 'searchKeywords'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim());
    res.status(200).json(parsed);
  } catch (error) {
    const formatted = formatError(error);
    res.status(formatted.status).json({ error: formatted.message });
  }
}
