import 'dotenv/config';
import express, { Request, Response } from 'express';
import http from 'http';
import fs from 'fs';
import path from 'path';
import zlib from 'zlib';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import type {
  FeedbackEntry,
  InquiryRequest,
  RecommendedTopic,
  SharedInquiryRoom,
  TeamMemberPresence,
  TeamTask,
} from './src/types/inquiry.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '1mb' }));

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(__dirname, '.data');
const ROOMS_FILE = path.join(DATA_DIR, 'collab-rooms.json');

const MEMBER_COLORS = [
  '#1E40AF',
  '#0F766E',
  '#B45309',
  '#6D28D9',
  '#BE123C',
  '#0369A1',
];

const roomsStore = new Map<string, SharedInquiryRoom>();
const roomConnections = new Map<string, Map<WebSocket, TeamMemberPresence>>();

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function saveRoomsToDisk() {
  try {
    ensureDataDir();
    const obj = Object.fromEntries(roomsStore.entries());
    fs.writeFileSync(ROOMS_FILE, JSON.stringify(obj, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist rooms:', err);
  }
}

function seedDemoRoomIfNeeded() {
  if (roomsStore.has('DEMO22')) return;
  const now = new Date().toISOString();
  const demoRoom: SharedInquiryRoom = {
    roomId: 'DEMO22',
    createdAt: now,
    createdBy: '김서연',
    subject: '확률과 통계',
    gradeLevel: '고2 일반선택',
    assessmentType: '코딩·데이터 분석',
    targetMajor: '컴퓨터공학·AI',
    competencies: ['수리·논리적 모델링', '데이터 분석·SW 구현', '시각화 및 발표 소통력'],
    hypothesis:
      '데이터 불균형 비율이 커질수록 AI 분류 모델의 정확도(Accuracy)와 실제 정밀도(Precision) 사이의 괴리가 커지며, 베이즈 정리 기반 사전 확률 보정으로 오진율을 정량적으로 낮출 수 있다.',
    currentTopic: {
      id: 'demo-topic-1',
      approachType: '데이터·수리 실증형',
      title: '불균형 의료 데이터에서 베이즈 정리 기반 AI 위양성(False Positive) 최소화 모델링',
      researchQuestion:
        '질병 유병률이 낮은 실제 의료 데이터에서 조건부 확률과 베이즈 정리가 AI 진단 모델의 신뢰도 평가에 어떤 수학적 기준을 제공하는가?',
      curriculumConnection:
        '2022 개정 [확률과 통계] 조건부확률, 사건의 독립과 종속 단원 및 [인공지능 수학] 분류 모델 평가 지표 연계',
      methodology: [
        '유병률(1%, 5%, 10%) 및 민감도·특이도 변화에 따른 사후확률(양성예측도) 수식 도출',
        '파이썬(Python) 또는 스프레드시트로 10,000건 가상 검진 데이터 시뮬레이션 구현',
        '혼동행렬(Confusion Matrix)과 정밀도·재현율 트레이드오프 그래프 시각화',
        '의료 AI 도입 시 요구되는 최소 특이도 기준 및 윤리적 가이드라인 제언',
      ],
      deliverableFormat: '수리 모델링 과정 + 파이썬 시뮬레이션 그래프가 포함된 4쪽 탐구 보고서 및 5분 발표 슬라이드',
      pros: [
        '확률과 통계 교과 핵심 개념(조건부확률)을 컴퓨터공학의 핵심 문제(데이터 불균형)와 직접 연결합니다.',
        '공개 통계 수치나 가상 시뮬레이션만으로도 완벽한 정량 분석이 가능해 실험 제약이 없습니다.',
      ],
      cons: [
        '단순 공식 대입에 그치면 깊이가 약해 보일 수 있으므로 민감도·특이도 변화 곡선까지 시각화해야 합니다.',
      ],
      competencyAlignment:
        '수학적 모델링을 코드로 검증하고 사회적 함의까지 도출하는 수리·SW 융합 역량이 돋보입니다.',
      difficulty: '심화·도전',
      estimatedHours: '5~7시간',
      followUps: [
        {
          title: '로지스틱 회귀와 ROC 곡선 아래 면적(AUC)을 활용한 다중 분류 임계값 최적화',
          linkedSubject: '인공지능 수학 / 미적분Ⅱ',
          direction: '정적 조건부확률에서 연속 확률분포와 미분 기반 최적화 문제로 확장',
          storylineNote: '2학년 확률 모델링이 3학년 AI 수학 최적화 탐구로 자연스럽게 심화됩니다.',
        },
      ],
    },
    revisions: [
      {
        version: 1,
        updatedBy: '김서연',
        updatedAt: now,
        note: 'AI 추천 주제에서 팀 협업방 생성 및 초기 가설 수립',
        title: '불균형 의료 데이터에서 베이즈 정리 기반 AI 위양성(False Positive) 최소화 모델링',
        researchQuestion:
          '질병 유병률이 낮은 실제 의료 데이터에서 조건부 확률과 베이즈 정리가 AI 진단 모델의 신뢰도 평가에 어떤 수학적 기준을 제공하는가?',
        hypothesis:
          '데이터 불균형 비율이 커질수록 AI 분류 모델의 정확도(Accuracy)와 실제 정밀도(Precision) 사이의 괴리가 커지며, 베이즈 정리 기반 사전 확률 보정으로 오진율을 정량적으로 낮출 수 있다.',
        deliverableFormat: '수리 모델링 과정 + 파이썬 시뮬레이션 그래프가 포함된 4쪽 탐구 보고서 및 5분 발표 슬라이드',
        methodology: [
          '유병률(1%, 5%, 10%) 및 민감도·특이도 변화에 따른 사후확률(양성예측도) 수식 도출',
          '파이썬(Python) 또는 스프레드시트로 10,000건 가상 검진 데이터 시뮬레이션 구현',
          '혼동행렬(Confusion Matrix)과 정밀도·재현율 트레이드오프 그래프 시각화',
          '의료 AI 도입 시 요구되는 최소 특이도 기준 및 윤리적 가이드라인 제언',
        ],
      },
    ],
    tasks: [
      {
        id: 'task-demo-1',
        title: '국내 희귀질환 유병률 공식 통계(KOSIS) 조사 및 표 정리',
        assignee: '김서연',
        dueLabel: '1차 마감',
        status: 'done',
        updatedBy: '김서연',
        updatedAt: now,
      },
      {
        id: 'task-demo-2',
        title: '파이썬 조건부확률 시뮬레이션 코드 및 민감도-특이도 그래프 생성',
        assignee: '박도윤',
        dueLabel: '2차 마감',
        status: 'in_progress',
        updatedBy: '박도윤',
        updatedAt: now,
      },
      {
        id: 'task-demo-3',
        title: '보고서 결론부 의료 AI 윤리·임계값 제언 작성 및 슬라이드 통합',
        assignee: '이지훈',
        dueLabel: '최종 마감',
        status: 'todo',
        updatedBy: '김서연',
        updatedAt: now,
      },
    ],
    feedbacks: [
      {
        id: 'fb-demo-1',
        authorName: '김서연',
        authorRole: '팀장 · 수리모델링',
        kind: 'progress',
        content: 'KOSIS에서 최근 3개년 건강검진 유병률 수치를 확보했습니다. 1%, 3%, 5% 세 구간으로 비교하면 차이가 선명하게 드러납니다.',
        createdAt: now,
        likes: ['박도윤'],
        resolved: false,
      },
      {
        id: 'fb-demo-2',
        authorName: '박도윤',
        authorRole: '데이터·SW 구현',
        kind: 'feedback',
        content: '혼동행렬 그래프에 더해 특이도가 95%일 때와 99%일 때 양성예측도 변화를 한 눈에 보는 히트맵을 추가하면 발표 전달력이 훨씬 높아질 것 같아요.',
        createdAt: now,
        likes: ['김서연'],
        resolved: false,
      },
    ],
  };

  roomsStore.set('DEMO22', demoRoom);
  saveRoomsToDisk();
}

function loadRoomsFromDisk() {
  try {
    if (fs.existsSync(ROOMS_FILE)) {
      const raw = fs.readFileSync(ROOMS_FILE, 'utf-8');
      const parsed = JSON.parse(raw) as Record<string, SharedInquiryRoom>;
      for (const [id, room] of Object.entries(parsed)) {
        roomsStore.set(id, room);
      }
    }
  } catch (err) {
    console.error('Failed to load rooms from disk:', err);
  }
  seedDemoRoomIfNeeded();
}

loadRoomsFromDisk();

function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return roomsStore.has(code) ? generateRoomCode() : code;
}

function getActiveMembers(roomId: string): TeamMemberPresence[] {
  const map = roomConnections.get(roomId);
  if (!map) return [];
  const seen = new Map<string, TeamMemberPresence>();
  for (const member of map.values()) {
    seen.set(member.clientId, member);
  }
  return Array.from(seen.values());
}

function broadcastToRoom(roomId: string, payload: unknown) {
  const map = roomConnections.get(roomId);
  if (!map) return;
  const serialized = JSON.stringify(payload);
  for (const [ws] of map.entries()) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(serialized);
    }
  }
}

function broadcastRoomSync(roomId: string) {
  const room = roomsStore.get(roomId);
  if (!room) return;
  broadcastToRoom(roomId, {
    type: 'room:sync',
    room,
    activeMembers: getActiveMembers(roomId),
  });
}

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('MISSING_API_KEY');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function isTransientGeminiError(error: unknown): boolean {
  const errObj = error as { status?: number; message?: string };
  const status = errObj?.status;
  const msg = (errObj?.message || '').toUpperCase();
  return (
    status === 503 ||
    status === 500 ||
    status === 502 ||
    status === 504 ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('HIGH DEMAND') ||
    msg.includes('DEADLINE_EXCEEDED') ||
    msg.includes('TIMEOUT') ||
    msg.includes('INTERNAL')
  );
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`TIMEOUT: ${label} exceeded ${ms}ms`));
    }, ms);
    promise.then(
      (val) => {
        clearTimeout(timer);
        resolve(val);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      }
    );
  });
}

async function generateContentWithRetry(
  ai: GoogleGenAI,
  params: {
    contents: string;
    systemInstruction: string;
    responseSchema: Record<string, unknown>;
    thinkingLevel?: ThinkingLevel;
    timeoutMs?: number;
  }
) {
  const timeoutMs = params.timeoutMs ?? 15000;
  const candidates: Array<{ model: string; useThinking: boolean; delayBeforeMs: number }> = [
    { model: 'gemini-4-hydrogen', useThinking: true, delayBeforeMs: 0 },
    { model: 'gemini-3.1-flash-lite', useThinking: false, delayBeforeMs: 0 },
    { model: 'gemini-4-hydrogen', useThinking: true, delayBeforeMs: 800 },
  ];

  let lastError: unknown;

  for (const candidate of candidates) {
    if (candidate.delayBeforeMs > 0) {
      await new Promise((resolve) => setTimeout(resolve, candidate.delayBeforeMs));
    }
    try {
      return await withTimeout(
        ai.models.generateContent({
          model: candidate.model,
          contents: params.contents,
          config: {
            systemInstruction: params.systemInstruction,
            ...(candidate.useThinking && params.thinkingLevel
              ? { thinkingConfig: { thinkingLevel: params.thinkingLevel } }
              : {}),
            responseMimeType: 'application/json',
            responseSchema: params.responseSchema,
          },
        }),
        timeoutMs,
        candidate.model
      );
    } catch (err) {
      lastError = err;
      const errMsg = err instanceof Error ? err.message : String(err);
      console.error(`[Gemini] ${candidate.model} failed:`, errMsg);
      if (!isTransientGeminiError(err)) {
        throw err;
      }
    }
  }

  throw lastError;
}

function parseModelJson<T>(rawText: string | undefined): T {
  const trimmed = (rawText ?? '{}')
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```\s*$/i, '')
    .trim();
  return JSON.parse(trimmed) as T;
}

function formatGeminiError(error: unknown): { status: number; message: string } {
  if (error instanceof Error && error.message === 'MISSING_API_KEY') {
    return {
      status: 500,
      message: 'GEMINI_API_KEY가 설정되지 않았습니다. Settings > Secrets 패널에서 API 키를 확인해 주세요.',
    };
  }

  const errObj = error as { status?: number; message?: string };
  const rawMessage = errObj?.message || '알 수 없는 오류가 발생했습니다.';
  const status = typeof errObj?.status === 'number' ? errObj.status : 500;

  if (status === 403 || rawMessage.includes('PERMISSION_DENIED') || rawMessage.includes('API_KEY_INVALID')) {
    return {
      status: 403,
      message: 'Gemini API 키 인증에 실패했습니다. Settings > Secrets 패널에서 유효한 키가 연결되어 있는지 확인해 주세요.',
    };
  }

  if (status === 429 || rawMessage.includes('RESOURCE_EXHAUSTED')) {
    return {
      status: 429,
      message: '요청 한도를 초과했습니다. 잠시 후 다시 시도해 주세요.',
    };
  }

  if (status === 503 || rawMessage.includes('UNAVAILABLE') || rawMessage.includes('high demand')) {
    return {
      status: 503,
      message: '현재 AI 서버 사용량이 일시적으로 많습니다. 5~10초 후 다시 한 번 요청해 주세요.',
    };
  }

  if (status === 404 || rawMessage.includes('NOT_FOUND')) {
    return {
      status: 404,
      message: '요청한 AI 모델을 찾을 수 없습니다. 서버 구성을 확인해 주세요.',
    };
  }

  return {
    status: status >= 400 && status < 600 ? status : 500,
    message: `요청 처리 중 오류가 발생했습니다: ${rawMessage}`,
  };
}

app.post('/api/recommend', async (req: Request, res: Response) => {
  try {
    const body = req.body as Partial<InquiryRequest>;
    const topic = (body.topic || '').trim();
    const subject = (body.subject || '').trim();
    const gradeLevel = body.gradeLevel || '고2 일반선택';
    const assessmentType = body.assessmentType || '탐구 보고서';
    const conditions = (body.conditions || '').trim();
    const targetMajor = (body.targetMajor || '').trim();
    const competencies = Array.isArray(body.competencies) ? body.competencies : [];
    const additionalFocus = (body.additionalFocus || '').trim();

    if (!topic) {
      res.status(400).json({ error: '탐구 주제 또는 관심 키워드를 입력해 주세요.' });
      return;
    }

    if (!targetMajor) {
      res.status(400).json({ error: '지망학과 또는 진로 희망 분야를 입력해 주세요.' });
      return;
    }

    const ai = getGeminiClient();

    const systemInstruction = `당신은 대한민국 '2022 개정 교육과정' 및 고교학점제, 학생부종합전형 교과 세특(세부능력 및 특기사항) 설계에 정통한 고등학교 수석 진로·진학 탐구 컨설턴트입니다.

학생이 입력한 주제, 수행평가 조건, 지망학과, 보여주고 싶은 역량을 종합 분석하여, 실제로 고등학교 수준에서 수행 가능하면서도 학업적 깊이와 전공 적합성이 돋보이는 **3개의 차별화된 탐구 주제**를 추천하세요.

반드시 지켜야 할 원칙:
1. **3개 주제의 관점 다각화**:
   - 주제 1: 교과 핵심 개념 심화·원리 탐구형
   - 주제 2: 실증 데이터 분석·실험/구현 중심형
   - 주제 3: 학제간 융합·사회적/윤리적 대안 제언형
2. **2022 개정 교육과정 정합성**:
   - 2022 개정 교육과정 교과 체계(공통과목: 통합과학/통합사회/공통수학 등, 일반선택: 대수/미적분Ⅰ/확률과 통계/물리학/화학/생명과학 등, 진로·융합선택: 인공지능 수학/경제 수학/세포와 물질대사/사회문제 탐구/데이터 과학/기후변화와 지속가능한 세계 등)의 실제 단원 개념과 자연스럽게 연결하세요.
3. **현실적이고 솔직한 장단점 분석**:
   - 장점(pros): 지망학과 연계성, 선택 역량 어필 포인트, 평가에서 차별화되는 지점을 구체적으로 작성하세요(각 2~3개).
   - 단점 및 보완점(cons): 고등학생이 실제로 부딪히는 어려움(자료 접근성, 실험 오차, 수학적 난이도, 시간 제약 등)을 솔직히 짚고, 반드시 '현실적인 보완 방법'을 함께 제시하세요(각 2~3개).
4. **이어갈 수 있는 후속 탐구(followUps) 설계**:
   - 각 주제마다 2개 이상의 구체적 후속 탐구를 제안하세요.
   - 후속 탐구는 다음 학기/학년의 다른 2022 개정 선택 과목(linkedSubject)과 어떻게 연결되는지, 어떤 심화 질문으로 이어지는지(direction), 학생부 진로 서사(storylineNote)가 어떻게 완성되는지 구체적으로 작성하세요.
5. **수행평가 조건 준수**:
   - 사용자가 제시한 평가 유형(${assessmentType})과 세부 조건(분량, 팀 구성, 기구 제약 등) 안에서 실행 가능한 탐구 방법(methodology)과 산출물 형태(deliverableFormat)를 제안하세요.
6. 한국어로 명확하고 학술적이면서도 고등학생이 바로 실행에 옮길 수 있는 실용적인 문체로 작성하세요. 허위 URL이나 존재하지 않는 논문 제목을 지어내지 마세요.`;

    const userPrompt = `다음 학생의 탐구 설계 요청에 맞춰 3개의 탐구 주제를 추천해 주세요.

- 관심 주제/키워드: ${topic}
- 관련 교과목: ${subject || '학생 입력 주제에 가장 적합한 2022 개정 교과목 자동 매칭'}
- 학년·과정 수준: ${gradeLevel}
- 수행평가 유형: ${assessmentType}
- 세부 조건 및 제약사항: ${conditions || '특별한 제약 없음 (고등학교 정규 수업·수행평가 범위 내)'}
- 지망학과: ${targetMajor}
- 보여주고 싶은 역량: ${competencies.length > 0 ? competencies.join(', ') : '학업적 탐구력, 전공 연계성, 논리적 사고력'}
- 추가 어필 포인트: ${additionalFocus || '없음'}`;

    const response = await generateContentWithRetry(ai, {
      contents: userPrompt,
      systemInstruction,
      thinkingLevel: ThinkingLevel.LOW,
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          advisorSummary: {
            type: Type.STRING,
            description: '입력된 조건(교육과정, 지망학과, 역량)을 종합한 전체 탐구 전략 총평 (2~3문장)',
          },
          topics: {
            type: Type.ARRAY,
            description: '서로 다른 접근 방식을 가진 3개의 추천 탐구 주제',
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING, description: '고유 식별자 (예: topic-1)' },
                approachType: { type: Type.STRING, description: '탐구 접근 유형' },
                title: { type: Type.STRING, description: '구체적이고 학술적인 탐구 주제명' },
                researchQuestion: { type: Type.STRING, description: '탐구를 관통하는 핵심 탐구 질문 1문장' },
                curriculumConnection: { type: Type.STRING, description: '2022 개정 교육과정 연계 과목 및 핵심 단원/성취기준 설명' },
                methodology: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: '수행평가 조건에 맞춘 구체적 단계별 탐구 진행 방법 3~4단계',
                },
                deliverableFormat: { type: Type.STRING, description: '수행평가 유형에 최적화된 산출물 구성 및 발표/보고서 전략' },
                pros: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: '이 주제의 강점과 평가 어필 포인트 2~3개',
                },
                cons: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: '예상되는 한계·어려움과 이를 극복하기 위한 구체적 보완 전략 2~3개',
                },
                competencyAlignment: { type: Type.STRING, description: '지망학과 및 선택한 역량이 세특에 드러나는 방식 요약' },
                difficulty: {
                  type: Type.STRING,
                  enum: ['기초·안정', '심화·도전', '융합·확장'],
                  description: '탐구 난이도 구분',
                },
                estimatedHours: { type: Type.STRING, description: '예상 소요 시간 (예: 4~6시간)' },
                followUps: {
                  type: Type.ARRAY,
                  description: '이 탐구 이후 이어갈 수 있는 후속 탐구 2~3개',
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING, description: '후속 탐구 주제명' },
                      linkedSubject: { type: Type.STRING, description: '연계되는 다음 학기/학년 2022 개정 과목' },
                      direction: { type: Type.STRING, description: '기존 탐구에서 어떻게 심화·확장되는지 구체적 방향' },
                      storylineNote: { type: Type.STRING, description: '학생부 진로 서사 및 세특 연계 효과' },
                    },
                    required: ['title', 'linkedSubject', 'direction', 'storylineNote'],
                  },
                },
              },
              required: [
                'id',
                'approachType',
                'title',
                'researchQuestion',
                'curriculumConnection',
                'methodology',
                'deliverableFormat',
                'pros',
                'cons',
                'competencyAlignment',
                'difficulty',
                'estimatedHours',
                'followUps',
              ],
            },
          },
        },
        required: ['advisorSummary', 'topics'],
      },
    });

    const parsed = parseModelJson<{ advisorSummary?: string; topics?: unknown[] }>(response.text);

    if (!parsed || !Array.isArray(parsed.topics) || parsed.topics.length === 0) {
      throw new Error('AI 응답 형식이 올바르지 않습니다. 다시 시도해 주세요.');
    }

    res.json(parsed);
  } catch (error) {
    const formatted = formatGeminiError(error);
    res.status(formatted.status).json({ error: formatted.message });
  }
});

app.post('/api/outline', async (req: Request, res: Response) => {
  try {
    const { topicData, requestContext } = req.body as {
      topicData?: RecommendedTopic;
      requestContext?: Partial<InquiryRequest>;
    };

    if (!topicData || !topicData.title) {
      res.status(400).json({ error: '계획서를 생성할 탐구 주제 정보가 필요합니다.' });
      return;
    }

    const ai = getGeminiClient();

    const response = await generateContentWithRetry(ai, {
      contents: `다음 고등학생 탐구 주제에 대해 바로 보고서나 발표 준비에 착수할 수 있는 구체적인 탐구 계획서 아웃라인을 작성해 주세요.

- 주제명: ${topicData.title}
- 핵심 탐구 질문: ${topicData.researchQuestion}
- 연계 교과: ${topicData.curriculumConnection}
- 수행평가 유형: ${requestContext?.assessmentType || '탐구 보고서'}
- 세부 조건: ${requestContext?.conditions || '표준 수행평가'}
- 지망학과: ${requestContext?.targetMajor || '관련 전공'}
- 탐구 방법 요약: ${(topicData.methodology || []).join(' / ')}`,
      systemInstruction:
        '당신은 2022 개정 교육과정 고등학교 탐구 멘토입니다. 학생이 실제로 자료를 찾고 목차를 구성해 탐구를 완수할 수 있도록 가설, 4~5단계 상세 목차, 활용 가능한 공신력 있는 자료/도구(통계청 KOSIS, RISS 학술검색, 공공데이터포털, 파이썬/지오지브라 등 실존 도구), 수행평가 자체 점검 체크리스트, 학술 검색 키워드를 JSON으로 제공하세요. 허위 URL이나 가짜 논문 제목을 만들지 마세요.',
      thinkingLevel: ThinkingLevel.LOW,
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          hypothesis: { type: Type.STRING, description: '검증하고자 하는 구체적 탐구 가설 또는 핵심 논지' },
          tableOfContents: {
            type: Type.ARRAY,
            description: '보고서/발표의 4~5단계 구성 목차',
            items: {
              type: Type.OBJECT,
              properties: {
                section: { type: Type.STRING, description: '목차 제목' },
                details: { type: Type.STRING, description: '해당 장에서 다뤄야 할 핵심 내용과 작성 팁' },
              },
              required: ['section', 'details'],
            },
          },
          dataAndTools: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '고등학생이 실제로 활용 가능한 데이터 출처 및 분석 도구 3~4개',
          },
          evaluationChecklist: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '제출 전 스스로 점검할 수행평가 루브릭 체크리스트 3~4개',
          },
          searchKeywords: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'RISS/KCI/DBpia 등에서 문헌 조사를 할 때 유용한 한국어·영어 검색 키워드 4~5개',
          },
        },
        required: ['hypothesis', 'tableOfContents', 'dataAndTools', 'evaluationChecklist', 'searchKeywords'],
      },
    });

    const parsed = parseModelJson<Record<string, unknown>>(response.text);
    res.json(parsed);
  } catch (error) {
    const formatted = formatGeminiError(error);
    res.status(formatted.status).json({ error: formatted.message });
  }
});

app.post('/api/rooms', (req: Request, res: Response) => {
  try {
    const { topic, requestContext, creatorName } = req.body as {
      topic?: RecommendedTopic;
      requestContext?: Partial<InquiryRequest>;
      creatorName?: string;
    };

    if (!topic || !topic.title) {
      res.status(400).json({ error: '협업방을 만들 탐구 주제가 필요합니다.' });
      return;
    }

    const roomId = generateRoomCode();
    const now = new Date().toISOString();
    const creator = (creatorName || '익명 학생').trim() || '익명 학생';

    const initialTasks: TeamTask[] = (topic.methodology || []).map((step, index) => ({
      id: `task-${Date.now()}-${index}`,
      title: step,
      assignee: index === 0 ? creator : '미배정',
      dueLabel: `${index + 1}단계`,
      status: 'todo',
      updatedBy: creator,
      updatedAt: now,
    }));

    const initialHypothesis = `본 탐구에서는 "${topic.researchQuestion}"을(를) 규명하기 위해 ${
      requestContext?.subject || '관련 교과'
    }의 핵심 원리를 바탕으로 체계적 분석을 수행한다.`;

    const newRoom: SharedInquiryRoom = {
      roomId,
      createdAt: now,
      createdBy: creator,
      subject: requestContext?.subject || '교과 융합',
      gradeLevel: requestContext?.gradeLevel || '고2 일반선택',
      assessmentType: requestContext?.assessmentType || '탐구 보고서',
      targetMajor: requestContext?.targetMajor || '진로 연계',
      competencies: Array.isArray(requestContext?.competencies) ? requestContext.competencies : [],
      currentTopic: topic,
      hypothesis: initialHypothesis,
      revisions: [
        {
          version: 1,
          updatedBy: creator,
          updatedAt: now,
          note: 'AI 추천 주제를 기반으로 팀 협업방 생성',
          title: topic.title,
          researchQuestion: topic.researchQuestion,
          hypothesis: initialHypothesis,
          deliverableFormat: topic.deliverableFormat,
          methodology: topic.methodology || [],
        },
      ],
      tasks: initialTasks,
      feedbacks: [
        {
          id: `fb-${Date.now()}`,
          authorName: creator,
          authorRole: '개설자',
          kind: 'progress',
          content: `팀 협업방을 개설했습니다. 초대 코드(${roomId}) 또는 공유 링크로 친구를 초대해 역할을 나누고 주제를 함께 발전시켜 보세요.`,
          createdAt: now,
          likes: [],
          resolved: false,
        },
      ],
    };

    roomsStore.set(roomId, newRoom);
    saveRoomsToDisk();
    res.status(201).json({ room: newRoom });
  } catch (error) {
    const formatted = formatGeminiError(error);
    res.status(formatted.status).json({ error: formatted.message });
  }
});

app.get('/api/rooms/:roomId', (req: Request, res: Response) => {
  const roomId = String(req.params.roomId || '').toUpperCase().trim();
  const room = roomsStore.get(roomId);
  if (!room) {
    res.status(404).json({ error: `코드 "${roomId}"에 해당하는 탐구 협업방을 찾을 수 없습니다.` });
    return;
  }
  res.json({ room, activeMembers: getActiveMembers(roomId) });
});

app.post('/api/rooms/:roomId/evolve', async (req: Request, res: Response) => {
  try {
    const roomId = String(req.params.roomId || '').toUpperCase().trim();
    const room = roomsStore.get(roomId);
    if (!room) {
      res.status(404).json({ error: '협업방을 찾을 수 없습니다.' });
      return;
    }

    const { prompt, authorName } = req.body as { prompt?: string; authorName?: string };
    const cleanPrompt = (prompt || '').trim();
    const actor = (authorName || '팀원').trim() || '팀원';

    if (!cleanPrompt) {
      res.status(400).json({ error: '주제를 어떻게 발전시킬지 팀 요청사항을 입력해 주세요.' });
      return;
    }

    const ai = getGeminiClient();
    const recentFeedbackSummary = room.feedbacks
      .slice(-5)
      .map((f) => `[${f.authorName}/${f.kind}] ${f.content}`)
      .join('\n');

    const response = await generateContentWithRetry(ai, {
      contents: `현재 팀이 진행 중인 2022 개정 교육과정 탐구 주제를 팀원의 요청사항과 피드백을 반영해 한 단계 발전시켜 주세요.

[현재 탐구 상태]
- 교과/수준: ${room.gradeLevel} / ${room.subject} (${room.assessmentType})
- 지망학과: ${room.targetMajor}
- 현재 주제명: ${room.currentTopic.title}
- 현재 탐구 질문: ${room.currentTopic.researchQuestion}
- 현재 가설: ${room.hypothesis}
- 현재 산출물 형태: ${room.currentTopic.deliverableFormat}
- 현재 진행 단계: ${room.currentTopic.methodology.join(' -> ')}

[최근 팀 피드백 및 진행 메모]
${recentFeedbackSummary || '없음'}

[팀원(${actor})의 주제 발전 요청]
${cleanPrompt}`,
      systemInstruction:
        '당신은 고등학생 팀 프로젝트의 공동 탐구 멘토입니다. 학생 팀의 기존 탐구 주제, 탐구 질문, 가설, 단계별 실행 방법, 산출물 전략을 요청사항에 맞게 더 날카롭고 실행 가능하게 다듬어 주세요. 한국어로 작성하세요.',
      thinkingLevel: ThinkingLevel.LOW,
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: '발전된 탐구 주제명' },
          researchQuestion: { type: Type.STRING, description: '개선된 핵심 탐구 질문' },
          hypothesis: { type: Type.STRING, description: '구체화된 팀 탐구 가설' },
          deliverableFormat: { type: Type.STRING, description: '업데이트된 산출물 전략' },
          methodology: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '개선된 3~5단계 탐구 수행 절차',
          },
          revisionNote: { type: Type.STRING, description: '이번 버전에서 무엇이 발전되었는지 1문장 요약' },
        },
        required: ['title', 'researchQuestion', 'hypothesis', 'deliverableFormat', 'methodology', 'revisionNote'],
      },
    });

    const parsed = parseModelJson<{
      title: string;
      researchQuestion: string;
      hypothesis: string;
      deliverableFormat: string;
      methodology: string[];
      revisionNote: string;
    }>(response.text);

    const now = new Date().toISOString();
    room.currentTopic = {
      ...room.currentTopic,
      title: parsed.title,
      researchQuestion: parsed.researchQuestion,
      deliverableFormat: parsed.deliverableFormat,
      methodology: parsed.methodology,
    };
    room.hypothesis = parsed.hypothesis;

    const nextVersion = (room.revisions[room.revisions.length - 1]?.version || 0) + 1;
    room.revisions.push({
      version: nextVersion,
      updatedBy: `${actor} (AI 공동 발전)`,
      updatedAt: now,
      note: parsed.revisionNote,
      title: parsed.title,
      researchQuestion: parsed.researchQuestion,
      hypothesis: parsed.hypothesis,
      deliverableFormat: parsed.deliverableFormat,
      methodology: parsed.methodology,
    });

    room.feedbacks.push({
      id: `fb-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      authorName: actor,
      authorRole: 'AI 공동 발전 반영',
      kind: 'idea',
      content: `[v${nextVersion} 주제 업데이트] ${parsed.revisionNote}`,
      createdAt: now,
      likes: [],
      resolved: false,
    });

    saveRoomsToDisk();
    broadcastRoomSync(roomId);
    res.json({ room });
  } catch (error) {
    const formatted = formatGeminiError(error);
    res.status(formatted.status).json({ error: formatted.message });
  }
});

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = CRC32_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function collectProjectFiles(rootDir: string, currentDir = rootDir): Array<{ relPath: string; fullPath: string }> {
  const excludedDirs = new Set(['node_modules', 'dist', '.git', '.data', '.next', 'coverage', '.aistudio']);
  const excludedFiles = new Set(['.DS_Store', '.env', '.env.local', '.env.production', '.env.development']);
  const results: Array<{ relPath: string; fullPath: string }> = [];

  for (const entry of fs.readdirSync(currentDir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (excludedDirs.has(entry.name)) continue;
      results.push(...collectProjectFiles(rootDir, path.join(currentDir, entry.name)));
    } else if (entry.isFile()) {
      if (excludedFiles.has(entry.name) || entry.name.endsWith('.log') || entry.name.endsWith('.zip')) {
        continue;
      }
      if (entry.name.startsWith('.env.') && entry.name !== '.env.example') {
        continue;
      }
      const fullPath = path.join(currentDir, entry.name);
      const relPath = path.relative(rootDir, fullPath).split(path.sep).join('/');
      results.push({ relPath, fullPath });
    }
  }
  return results;
}

function buildZipBuffer(files: Array<{ relPath: string; fullPath: string }>): Buffer {
  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const file of files) {
    const raw = fs.readFileSync(file.fullPath);
    const compressed = zlib.deflateRawSync(raw);
    const nameBuf = Buffer.from(file.relPath, 'utf-8');
    const fileCrc = crc32(raw);

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4);
    localHeader.writeUInt16LE(0x0800, 6); // UTF-8 flag
    localHeader.writeUInt16LE(8, 8); // deflate
    localHeader.writeUInt16LE(0, 10);
    localHeader.writeUInt16LE(0x0021, 12);
    localHeader.writeUInt32LE(fileCrc, 14);
    localHeader.writeUInt32LE(compressed.length, 18);
    localHeader.writeUInt32LE(raw.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28);

    localParts.push(localHeader, nameBuf, compressed);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(20, 4);
    centralHeader.writeUInt16LE(20, 6);
    centralHeader.writeUInt16LE(0x0800, 8); // UTF-8 flag
    centralHeader.writeUInt16LE(8, 10); // deflate
    centralHeader.writeUInt16LE(0, 12);
    centralHeader.writeUInt16LE(0x0021, 14);
    centralHeader.writeUInt32LE(fileCrc, 16);
    centralHeader.writeUInt32LE(compressed.length, 20);
    centralHeader.writeUInt32LE(raw.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(offset, 42);

    centralParts.push(centralHeader, nameBuf);
    offset += localHeader.length + nameBuf.length + compressed.length;
  }

  const centralDir = Buffer.concat(centralParts);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(files.length, 8);
  eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(centralDir.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localParts, centralDir, eocd]);
}

app.get('/api/export-zip', (_req: Request, res: Response) => {
  try {
    const files = collectProjectFiles(__dirname);
    const zipBuffer = buildZipBuffer(files);
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="inquiry-atelier-github.zip"');
    res.setHeader('Content-Length', String(zipBuffer.length));
    res.send(zipBuffer);
  } catch (err) {
    console.error('Failed to build source zip:', err);
    res.status(500).json({ error: '소스 코드 압축 파일을 생성하는 중 오류가 발생했습니다.' });
  }
});

async function startServer() {
  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    let joinedRoomId: string | null = null;

    ws.on('message', (rawData) => {
      try {
        const msg = JSON.parse(rawData.toString());
        const roomId = typeof msg.roomId === 'string' ? msg.roomId.toUpperCase().trim() : '';

        if (msg.type === 'room:join') {
          const room = roomsStore.get(roomId);
          if (!room) {
            ws.send(JSON.stringify({ type: 'room:error', message: `협업방(${roomId})을 찾을 수 없습니다.` }));
            return;
          }

          if (joinedRoomId && joinedRoomId !== roomId) {
            const prevMap = roomConnections.get(joinedRoomId);
            prevMap?.delete(ws);
            broadcastToRoom(joinedRoomId, {
              type: 'presence:update',
              activeMembers: getActiveMembers(joinedRoomId),
            });
          }

          joinedRoomId = roomId;
          if (!roomConnections.has(roomId)) {
            roomConnections.set(roomId, new Map());
          }
          const connMap = roomConnections.get(roomId)!;
          const clientId = String(msg.clientId || Math.random().toString(36).slice(2));
          const presence: TeamMemberPresence = {
            clientId,
            name: String(msg.name || '참여 학생').trim() || '참여 학생',
            role: String(msg.role || '팀원').trim() || '팀원',
            color: MEMBER_COLORS[connMap.size % MEMBER_COLORS.length],
            joinedAt: new Date().toISOString(),
          };
          connMap.set(ws, presence);

          ws.send(
            JSON.stringify({
              type: 'room:sync',
              room,
              activeMembers: getActiveMembers(roomId),
            })
          );
          broadcastToRoom(roomId, {
            type: 'presence:update',
            activeMembers: getActiveMembers(roomId),
          });
          return;
        }

        if (!roomId || !roomsStore.has(roomId)) {
          ws.send(JSON.stringify({ type: 'room:error', message: '유효하지 않은 협업방입니다.' }));
          return;
        }

        const room = roomsStore.get(roomId)!;
        const now = new Date().toISOString();

        if (msg.type === 'topic:update') {
          const patch = msg.patch || {};
          const authorName = String(msg.authorName || '팀원').trim() || '팀원';
          const nextTitle = typeof patch.title === 'string' ? patch.title.trim() : room.currentTopic.title;
          const nextQuestion =
            typeof patch.researchQuestion === 'string'
              ? patch.researchQuestion.trim()
              : room.currentTopic.researchQuestion;
          const nextHypothesis =
            typeof patch.hypothesis === 'string' ? patch.hypothesis.trim() : room.hypothesis;
          const nextDeliverable =
            typeof patch.deliverableFormat === 'string'
              ? patch.deliverableFormat.trim()
              : room.currentTopic.deliverableFormat;
          const nextMethodology = Array.isArray(patch.methodology)
            ? patch.methodology.map((s: unknown) => String(s).trim()).filter(Boolean)
            : room.currentTopic.methodology;

          room.currentTopic = {
            ...room.currentTopic,
            title: nextTitle || room.currentTopic.title,
            researchQuestion: nextQuestion || room.currentTopic.researchQuestion,
            deliverableFormat: nextDeliverable || room.currentTopic.deliverableFormat,
            methodology: nextMethodology.length > 0 ? nextMethodology : room.currentTopic.methodology,
          };
          room.hypothesis = nextHypothesis;

          const nextVersion = (room.revisions[room.revisions.length - 1]?.version || 0) + 1;
          room.revisions.push({
            version: nextVersion,
            updatedBy: authorName,
            updatedAt: now,
            note: String(patch.note || '팀원이 탐구 기획 내용을 직접 수정했습니다.').trim(),
            title: room.currentTopic.title,
            researchQuestion: room.currentTopic.researchQuestion,
            hypothesis: room.hypothesis,
            deliverableFormat: room.currentTopic.deliverableFormat,
            methodology: room.currentTopic.methodology,
          });

          saveRoomsToDisk();
          broadcastRoomSync(roomId);
          return;
        }

        if (msg.type === 'task:create') {
          const incoming = msg.task as TeamTask | undefined;
          if (!incoming || !incoming.id || !incoming.title?.trim()) return;
          if (room.tasks.some((t) => t.id === incoming.id)) return; // Idempotency guard

          room.tasks.push({
            id: incoming.id,
            title: incoming.title.trim(),
            assignee: (incoming.assignee || '미배정').trim(),
            dueLabel: (incoming.dueLabel || '일정 미정').trim(),
            status: incoming.status || 'todo',
            updatedBy: incoming.updatedBy || '팀원',
            updatedAt: now,
          });
          saveRoomsToDisk();
          broadcastRoomSync(roomId);
          return;
        }

        if (msg.type === 'task:update') {
          const taskId = String(msg.taskId || '');
          const patch = msg.patch || {};
          const target = room.tasks.find((t) => t.id === taskId);
          if (!target) return;

          if (typeof patch.title === 'string' && patch.title.trim()) target.title = patch.title.trim();
          if (typeof patch.assignee === 'string') target.assignee = patch.assignee.trim() || '미배정';
          if (typeof patch.dueLabel === 'string') target.dueLabel = patch.dueLabel.trim() || '일정 미정';
          if (patch.status === 'todo' || patch.status === 'in_progress' || patch.status === 'done') {
            target.status = patch.status;
          }
          target.updatedBy = String(patch.updatedBy || '팀원');
          target.updatedAt = now;

          saveRoomsToDisk();
          broadcastRoomSync(roomId);
          return;
        }

        if (msg.type === 'task:delete') {
          const taskId = String(msg.taskId || '');
          const nextTasks = room.tasks.filter((t) => t.id !== taskId);
          if (nextTasks.length === room.tasks.length) return;
          room.tasks = nextTasks;
          saveRoomsToDisk();
          broadcastRoomSync(roomId);
          return;
        }

        if (msg.type === 'feedback:create') {
          const entry = msg.entry as FeedbackEntry | undefined;
          if (!entry || !entry.id || !entry.content?.trim()) return;
          if (room.feedbacks.some((f) => f.id === entry.id)) return; // Idempotency guard

          room.feedbacks.push({
            id: entry.id,
            authorName: (entry.authorName || '팀원').trim(),
            authorRole: (entry.authorRole || '팀원').trim(),
            kind: entry.kind || 'feedback',
            content: entry.content.trim(),
            createdAt: now,
            likes: [],
            resolved: false,
          });
          saveRoomsToDisk();
          broadcastRoomSync(roomId);
          return;
        }

        if (msg.type === 'feedback:toggle_like') {
          const entryId = String(msg.entryId || '');
          const actorName = String(msg.actorName || '').trim();
          if (!actorName) return;
          const target = room.feedbacks.find((f) => f.id === entryId);
          if (!target) return;

          if (target.likes.includes(actorName)) {
            target.likes = target.likes.filter((n) => n !== actorName);
          } else {
            target.likes.push(actorName);
          }
          saveRoomsToDisk();
          broadcastRoomSync(roomId);
          return;
        }

        if (msg.type === 'feedback:toggle_resolve') {
          const entryId = String(msg.entryId || '');
          const target = room.feedbacks.find((f) => f.id === entryId);
          if (!target) return;
          target.resolved = !target.resolved;
          saveRoomsToDisk();
          broadcastRoomSync(roomId);
          return;
        }
      } catch (err) {
        console.error('WebSocket message error:', err);
      }
    });

    ws.on('close', () => {
      if (joinedRoomId) {
        const map = roomConnections.get(joinedRoomId);
        map?.delete(ws);
        broadcastToRoom(joinedRoomId, {
          type: 'presence:update',
          activeMembers: getActiveMembers(joinedRoomId),
        });
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
