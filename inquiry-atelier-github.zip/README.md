# 탐구아틀리에 (2022 개정 교육과정 고교 탐구 설계 & 팀 협업)

2022 개정 교육과정 고등학생을 위한 수행평가·교과 세특 맞춤형 탐구 주제 추천, 주제별 장단점 및 후속 탐구 설계, 그리고 친구들과 함께 진행하는 실시간 팀 협업 워크스페이스입니다.

## 주요 기능

- **AI 탐구 주제 3안 추천 (`/api/recommend`)**: 주제/단원, 과정 수준(`고1 공통` · `고2 일반선택` · `고3 진로·융합선택`), 수행평가 유형, 지망학과, 보여주고 싶은 역량을 입력하면 관점이 다른 3개 주제를 장단점·보완 전략·후속 탐구와 함께 제안합니다.
- **상세 계획서 생성 (`/api/outline`)**: 선택한 주제의 탐구 가설, 보고서/발표 목차, 자료 출처·도구, 자기점검 체크리스트를 즉시 생성합니다.
- **항목별 장단점 비교 & 보관함**: 추천 주제를 가로형 비교표로 비교하고, `localStorage` 보관함에 저장하거나 마크다운으로 복사할 수 있습니다.
- **실시간 팀 협업방 (`server.ts` + WebSocket `/ws`)**: 초대 코드/공유 링크(`?room=XXXXXX`)로 친구를 초대해 역할 분담, 실시간 진행률 업데이트, 상호 피드백, AI 공동 발전 기능을 함께 사용할 수 있습니다.

---

## 로컬 실행 방법

```bash
npm install
cp .env.example .env
# .env 파일에 GEMINI_API_KEY 입력
npm run dev
```

개발 서버는 `http://localhost:3000`에서 실행됩니다.

---

## GitHub 업로드 방법

```bash
git init
git add .
git commit -m "feat: 2022 curriculum inquiry atelier with realtime collaboration"
git branch -M main
git remote add origin https://github.com/<USERNAME>/<REPO_NAME>.git
git push -u origin main
```

---

## Vercel 배포 안내

이 프로젝트는 **Vercel Serverless Functions (`/api/recommend.ts`, `/api/outline.ts`)** 및 `vercel.json`이 포함되어 있어 GitHub 저장소를 Vercel에 연결하면 바로 빌드·배포됩니다.

1. Vercel에서 GitHub 저장소를 Import합니다. (Framework Preset: `Vite`, Output Directory: `dist`)
2. **Project Settings → Environment Variables**에 아래 환경변수를 등록합니다.
   - `GEMINI_API_KEY`: Google AI Studio Gemini API 키
3. Deploy를 실행하면 **탐구 주제 추천, 상세 계획서 생성, 장단점 비교, 내 보관함** 기능이 즉시 동작합니다.

### 실시간 WebSocket 협업방까지 배포에서 함께 사용하려면

Vercel Serverless 환경은 상시 WebSocket 연결(`/ws`)과 로컬 파일 저장을 유지하지 않습니다. 실시간 팀 협업방까지 프로덕션에서 사용하려면 아래 두 가지 중 하나를 선택하세요.

1. **풀스택 단일 서버 배포 (권장)**: Render, Railway, Fly.io, Google Cloud Run 등 Node 서버 실행 플랫폼에서 `npm run build` 후 `npm start` (`node server.ts`)로 배포하면 AI API + WebSocket 실시간 협업방이 한 번에 동작합니다.
2. **Vercel(프론트엔드+AI) + 외부 Node 서버(협업방) 하이브리드**:
   - Render/Railway/Cloud Run 등에 `server.ts`를 띄우고 `GEMINI_API_KEY`, `CORS_ORIGIN=https://<your-vercel-app>.vercel.app`을 설정합니다.
   - Vercel 환경변수에 `VITE_BACKEND_URL=https://<your-node-server>`를 추가하고 재배포하면 협업방 API/WebSocket이 해당 서버로 연결됩니다.
